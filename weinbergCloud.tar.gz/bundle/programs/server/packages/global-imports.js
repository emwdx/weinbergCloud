/* Imports for global scope */

Router = Package['iron:router'].Router;
RouteController = Package['iron:router'].RouteController;
Logic = Package['logic-solver'].Logic;
Roles = Package['alanning:roles'].Roles;
ManageUsers = Package['cfly15:manage-users'].ManageUsers;
ReactiveVar = Package['reactive-var'].ReactiveVar;
_ = Package.underscore._;
Raphael = Package['clubfest:raphael'].Raphael;
Accounts = Package['accounts-base'].Accounts;
Iron = Package['iron:core'].Iron;
AccountsTemplates = Package['useraccounts:core'].AccountsTemplates;
Meteor = Package.meteor.Meteor;
global = Package.meteor.global;
meteorEnv = Package.meteor.meteorEnv;
WebApp = Package.webapp.WebApp;
main = Package.webapp.main;
WebAppInternals = Package.webapp.WebAppInternals;
Log = Package.logging.Log;
Tracker = Package.deps.Tracker;
Deps = Package.deps.Deps;
DDP = Package['ddp-client'].DDP;
DDPServer = Package['ddp-server'].DDPServer;
MongoInternals = Package.mongo.MongoInternals;
Mongo = Package.mongo.Mongo;
Blaze = Package.ui.Blaze;
UI = Package.ui.UI;
Handlebars = Package.ui.Handlebars;
Spacebars = Package.spacebars.Spacebars;
check = Package.check.check;
Match = Package.check.Match;
Random = Package.random.Random;
EJSON = Package.ejson.EJSON;
T9n = Package['softwarerero:accounts-t9n'].T9n;
HTML = Package.htmljs.HTML;

