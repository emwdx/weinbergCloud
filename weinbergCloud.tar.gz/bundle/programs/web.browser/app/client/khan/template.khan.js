(function(){
Template.__checkName("listQuestions");
Template["listQuestions"] = new Template("Template.listQuestions", (function() {
  var view = this;
  return HTML.DIV({
    "class": "row"
  }, "\n  ", HTML.DIV({
    "class": "col-md-8",
    id: "questionList"
  }, "\n    ", Spacebars.include(view.lookupTemplate("courseUnitStandard")), "\n\n     ", Blaze.If(function() {
    return Spacebars.call(view.templateInstance().subscriptionsReady());
  }, function() {
    return [ "\n\n      ", Blaze.Each(function() {
      return Spacebars.call(view.lookup("question"));
    }, function() {
      return [ "\n\n      ", HTML.DIV({
        "class": "questionContainer"
      }, "\n\n      ", Spacebars.include(view.lookupTemplate("questionView")), "\n\n    "), "\n\n      " ];
    }), "\n\n      " ];
  }), "\n\n      ", Blaze.Unless(function() {
    return Spacebars.call(view.templateInstance().subscriptionsReady());
  }, function() {
    return [ "\n      ", Spacebars.include(view.lookupTemplate("loading")), "\n      " ];
  }), "\n\n\n    "), "\n    ", HTML.DIV({
    "class": "col-md-4"
  }, "\n      ", Spacebars.include(view.lookupTemplate("assignQuiz")), "\n    "), "\n  ");
}));

Template.__checkName("questionAdd");
Template["questionAdd"] = new Template("Template.questionAdd", (function() {
  var view = this;
  return [ HTML.H3(Blaze.View("lookup:questionMode", function() {
    return Spacebars.mustache(view.lookup("questionMode"));
  }), " Question:"), HTML.Raw("\n<hr>\n"), HTML.DIV({
    "class": "row"
  }, "\n", HTML.DIV({
    "class": "col-md-6",
    id: "questionAddPreviewText"
  }, "\n  ", HTML.Raw('<h5 class="text-info text-center">Question Text Preview:</h5>'), "\n\n  ", Blaze.View("lookup:previewText", function() {
    return Spacebars.makeRaw(Spacebars.mustache(view.lookup("previewText")));
  }), "\n"), "\n", HTML.DIV({
    "class": "col-md-6",
    id: "questionAddPreviewAnswer"
  }, "\n  ", HTML.Raw('<h5 class="text-info text-center">Question Answer Preview:</h5>'), "\n\n  ", Blaze.View("lookup:previewAnswer", function() {
    return Spacebars.makeRaw(Spacebars.mustache(view.lookup("previewAnswer")));
  }), "\n"), "\n\n"), HTML.Raw("\n\n<hr>\n\n"), HTML.DIV({
    "class": "row"
  }, "\n", HTML.DIV({
    "class": "col-md-6"
  }, "\nQuestion Text:\n", HTML.DIV({
    "class": "form-group"
  }, "\n  ", HTML.TEXTAREA({
    id: "questionText",
    "class": "form-control questionEntry",
    value: function() {
      return [ "    ", Spacebars.makeRaw(Spacebars.mustache(view.lookup("text"))), " " ];
    }
  }), "\n\n"), "\n"), "\n", HTML.DIV({
    "class": "col-md-6"
  }, "\n", HTML.DIV({
    "class": "form-group"
  }, "\nQuestion Answer:\n  ", HTML.TEXTAREA({
    id: "questionAnswer",
    "class": "form-control questionEntry",
    value: function() {
      return [ "    ", Spacebars.makeRaw(Spacebars.mustache(view.lookup("answer"))), " " ];
    }
  }), "\n\n"), "\n"), "\n"), HTML.Raw('\n\n<div class="row">\n  <div class="col-md-2">\n<button id="addVar">Add Variable</button>\n</div>\n<div class="col-md-2">\n<button id="processVariables">Insert Values</button>\n</div>\n</div>\n'), HTML.DIV({
    id: "varList"
  }, "\n", Blaze.Each(function() {
    return Spacebars.call(view.lookup("vars"));
  }, function() {
    return [ "\n\n\n", Spacebars.include(view.lookupTemplate("variable")), "\n\n\n\n" ];
  }), "\n"), HTML.Raw("\n<hr>\n"), HTML.DIV({
    "class": "row"
  }, "\n  ", HTML.DIV({
    "class": "col-md-12 checkbox"
  }, "\n\n    ", HTML.INPUT(HTML.Attrs({
    type: "checkbox",
    id: "shareQuestion"
  }, function() {
    return Spacebars.attrMustache(view.lookup("isPublic"));
  })), "\n", HTML.Raw('<label>Check here to share this question with the <span class="text-info">Question-Builder</span> community.</label>'), "\n"), "\n"), "\n", HTML.DIV({
    "class": "row"
  }, "\n  ", HTML.DIV({
    "class": "col-md-12 text-center"
  }, "\n", HTML.INPUT({
    type: "text",
    id: "addQuestionTitle",
    "class": "form-control",
    placeholder: "Enter an optional title here.",
    value: function() {
      return Spacebars.mustache(view.lookup("currentTitle"));
    }
  }), "\n"), "\n"), "\n", Spacebars.include(view.lookupTemplate("courseUnitStandard")), HTML.Raw('\n<div class="row">\n  <div class="col-md-12 text-center">\n<button id="submitQuestion" class="btn btn-primary">Submit Question</button>\n</div>\n</div>') ];
}));

Template.__checkName("variable");
Template["variable"] = new Template("Template.variable", (function() {
  var view = this;
  return HTML.DIV({
    "class": "varContainer"
  }, "\n  ", HTML.DIV({
    "class": "row"
  }, "\n\n    ", HTML.DIV({
    "class": "col-md-2 form-horizontal control-group"
  }, "\n\n\n      ", HTML.INPUT({
    type: "text",
    placeholder: "Variable ID",
    "class": "varID form-control",
    value: function() {
      return Spacebars.mustache(view.lookup("name"));
    },
    "data-toggle": "tooltip",
    "data-placement": "top",
    "data-original-title": "Give this variable a name. It must be different from the rest of the variable in the list."
  }), "\n    "), "\n\n\n        ", HTML.DIV({
    "class": "col-md-2 form-horizontal control-group"
  }, "\n      ", HTML.SELECT({
    name: "varTypeSelect",
    "class": "form-control varTypeSelect"
  }, "\n\n        ", HTML.OPTION(HTML.Attrs({
    value: "rand-int"
  }, function() {
    return Spacebars.attrMustache(view.lookup("selectedIf"), view.lookup("type"), "rand-int");
  }), "Random Integer"), "\n        ", HTML.OPTION(HTML.Attrs({
    value: "rand-dec"
  }, function() {
    return Spacebars.attrMustache(view.lookup("selectedIf"), view.lookup("type"), "rand-dec");
  }), "Random Decimal"), "\n        ", HTML.OPTION(HTML.Attrs({
    value: "calc-val"
  }, function() {
    return Spacebars.attrMustache(view.lookup("selectedIf"), view.lookup("type"), "calc-val");
  }), "Calculated Value"), "\n        ", HTML.OPTION(HTML.Attrs({
    value: "customJS"
  }, function() {
    return Spacebars.attrMustache(view.lookup("selectedIf"), view.lookup("type"), "customJS");
  }), "Custom JS"), "\n      "), "\n\n    "), "\n    ", HTML.DIV({
    "class": "col-md-6 form-horizontal"
  }, "\n\n      ", Blaze.If(function() {
    return Spacebars.call(view.lookup("isRandInt"));
  }, function() {
    return [ "\n\n      ", Spacebars.include(view.lookupTemplate("varRandomInt")), "\n        " ];
  }), "\n      ", Blaze.If(function() {
    return Spacebars.call(view.lookup("isRandDec"));
  }, function() {
    return [ "\n      ", Spacebars.include(view.lookupTemplate("varRandomDec")), "\n      " ];
  }), "\n      ", Blaze.If(function() {
    return Spacebars.call(view.lookup("isCalcVal"));
  }, function() {
    return [ "\n      ", Spacebars.include(view.lookupTemplate("varCalcVal")), "\n      " ];
  }), "\n      ", Blaze.If(function() {
    return Spacebars.call(view.lookup("isCustomJS"));
  }, function() {
    return [ "\n      ", Spacebars.include(view.lookupTemplate("varCustomJS")), "\n      " ];
  }), "\n\n    "), "\n    ", HTML.DIV({
    "class": "col-md-2 form-horizontal"
  }, "\n      ", HTML.Raw('<button class="varDelete text-danger btn"><span class="glyphicon glyphicon-trash"></span></button>'), "\n      ", Blaze.View("lookup:..value", function() {
    return Spacebars.mustache(Spacebars.dot(view.lookup("."), "value"));
  }), "\n    "), "\n\n    "), "\n\n  ");
}));

Template.__checkName("varRandomInt");
Template["varRandomInt"] = new Template("Template.varRandomInt", (function() {
  var view = this;
  return [ HTML.DIV({
    "class": "col-md-3"
  }, "\n      ", HTML.INPUT({
    type: "number",
    "class": "varRandomIntMin varRandInt form-control",
    placeholder: "min",
    value: function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("."), "options", "min"));
    },
    "data-toggle": "tooltip",
    "data-placement": "top",
    "data-original-title": function() {
      return [ "Minimum value for ", Spacebars.mustache(Spacebars.dot(view.lookup("."), "name")) ];
    }
  }), "\n    "), "\n      ", HTML.DIV({
    "class": "col-md-3"
  }, "\n      ", HTML.INPUT({
    type: "number",
    "class": "varRandomIntMax varRandInt form-control",
    placeholder: "max",
    value: function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("."), "options", "max"));
    },
    "data-toggle": "tooltip",
    "data-placement": "top",
    "data-original-title": function() {
      return [ "Maximum value for ", Spacebars.mustache(Spacebars.dot(view.lookup("."), "name")) ];
    }
  }), "\n    "), "\n      ", HTML.DIV({
    "class": "col-md-6"
  }, "\n      ", HTML.INPUT({
    type: "text",
    "class": "varRandomIntExclude  varRandInt form-control",
    placeholder: "Values to Exclude?",
    value: function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("."), "options", "exclude"));
    },
    "data-toggle": "tooltip",
    "data-placement": "top",
    "data-original-title": function() {
      return [ "If there are values between ", Spacebars.mustache(Spacebars.dot(view.lookup("."), "options", "min")), " and ", Spacebars.mustache(Spacebars.dot(view.lookup("."), "options", "max")), " that you want to exclude, separate them with commas. (E.g. -1,0,1)" ];
    }
  }), "\n      ") ];
}));

Template.__checkName("varRandomDec");
Template["varRandomDec"] = new Template("Template.varRandomDec", (function() {
  var view = this;
  return [ HTML.DIV({
    "class": "col-md-3"
  }, "\n      ", HTML.INPUT({
    type: "number",
    "class": "varRandomDecMin varRandDec form-control",
    placeholder: "min",
    value: function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("."), "options", "min"));
    },
    "data-toggle": "tooltip",
    "data-placement": "top",
    "data-original-title": function() {
      return [ "Minimum value for ", Spacebars.mustache(Spacebars.dot(view.lookup("."), "name")) ];
    }
  }), "\n  "), "\n      ", HTML.DIV({
    "class": "col-md-3"
  }, "\n      ", HTML.INPUT({
    type: "number",
    "class": "varRandomDecMax varRandDec form-control",
    placeholder: "max",
    value: function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("."), "options", "max"));
    },
    "data-toggle": "tooltip",
    "data-placement": "top",
    "data-original-title": function() {
      return [ "Maximum value for ", Spacebars.mustache(Spacebars.dot(view.lookup("."), "name")) ];
    }
  }), "\n    "), "\n      ", HTML.DIV({
    "class": "col-md-6"
  }, "\n      ", HTML.INPUT({
    type: "number",
    "class": "varRandomDecDP varRandDec form-control",
    placeholder: "Decimal Places",
    "data-toggle": "tooltip",
    "data-placement": "top",
    "data-original-title": function() {
      return [ "Enter the number of decimal places ", Spacebars.mustache(Spacebars.dot(view.lookup("."), "name")), " should have." ];
    }
  }), "\n        ") ];
}));

Template.__checkName("varCalcVal");
Template["varCalcVal"] = new Template("Template.varCalcVal", (function() {
  var view = this;
  return HTML.DIV({
    "class": "control-group"
  }, "\n      Enter JS code to calculate this variable's value:\n      ", HTML.INPUT({
    type: "text",
    "class": "varCalcValText form-control",
    value: function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("."), "text"));
    },
    "data-toggle": "tooltip",
    "data-placement": "top",
    "data-original-title": "This must be valid javascript "
  }), "\n   ");
}));

Template.__checkName("varCustomJS");
Template["varCustomJS"] = new Template("Template.varCustomJS", (function() {
  var view = this;
  return HTML.DIV({
    "class": "control-group"
  }, HTML.Raw("\n    <code>(function(){</code>\n      "), HTML.TEXTAREA({
    "class": "varCustomJS form-control",
    rows: "6",
    cols: "20",
    value: function() {
      return [ "        ", Blaze.If(function() {
        return Spacebars.call(Spacebars.dot(view.lookup("."), "text"));
      }, function() {
        return [ "\n        ", Blaze.View("lookup:..text", function() {
          return Spacebars.mustache(Spacebars.dot(view.lookup("."), "text"));
        }), "\n        " ];
      }), "\n\n        ", Blaze.Unless(function() {
        return Spacebars.call(Spacebars.dot(view.lookup("."), "text"));
      }, function() {
        return "\n\n\n\n          //Your code goes here! Be sure to enter a return statement.\n\n\n\n\n\n          ";
      }), "\n      " ];
    }
  }), HTML.Raw("\n     <code>  })()</code>\n   "));
}));

Template.__checkName("questionView");
Template["questionView"] = new Template("Template.questionView", (function() {
  var view = this;
  return [ HTML.DIV({
    "class": "row "
  }, "\n\n  ", HTML.DIV({
    "class": "col-md-6"
  }, "\n    ", HTML.H5("\n      ", Blaze.View("lookup:course", function() {
    return Spacebars.mustache(view.lookup("course"));
  }), " - ", Blaze.View("lookup:unit", function() {
    return Spacebars.mustache(view.lookup("unit"));
  }), ".", Blaze.View("lookup:standard", function() {
    return Spacebars.mustache(view.lookup("standard"));
  }), "\n    "), "\n  "), "\n\n  "), "\n    ", HTML.DIV({
    "class": "row question"
  }, "\n\n  ", HTML.DIV({
    "class": "questionText col-md-5"
  }, "\n  ", HTML.Raw('<h6 class="text-info">Question Text:</h6>'), "\n    ", Blaze.View("lookup:questionText", function() {
    return Spacebars.makeRaw(Spacebars.mustache(view.lookup("questionText")));
  }), "\n  "), "\n  ", HTML.DIV({
    "class": "questionAnswer col-md-5"
  }, "\n  ", HTML.Raw('<h6 class="text-info ">Question Answer:</h6>'), "\n    ", Blaze.View("lookup:questionAnswer", function() {
    return Spacebars.makeRaw(Spacebars.mustache(view.lookup("questionAnswer")));
  }), "\n  "), "\n  ", HTML.Raw('<div class="col-md-2">\n  <button class="reloadQuestion"><span class="glyphicon glyphicon-random"></span></button>\n\n\n  </div>'), "\n\n    "), HTML.Raw('\n    <div class="row questionControlBar">\n      <div class="col-md-4">\n\n    <button class="questionDelete btn btn-danger glyphicon glyphicon-trash"></button>\n\n    <button class="questionCopy btn btn-success glyphicon glyphicon-copy"></button>\n\n    <button class="questionEdit btn btn-info glyphicon glyphicon-pencil"></button>\n\n    <button class="addToQuiz btn btn-warning glyphicon glyphicon-list-alt"></button>\n\n  </div>\n  </div>') ];
}));

Template.__checkName("loading");
Template["loading"] = new Template("Template.loading", (function() {
  var view = this;
  return [ HTML.Raw('<p class="text-center text-info">Loading...</p>\n    '), Spacebars.include(view.lookupTemplate("spinner")) ];
}));

}).call(this);
