(function(){
Template.__checkName("assignQuiz");
Template["assignQuiz"] = new Template("Template.assignQuiz", (function() {
  var view = this;
  return [ HTML.Raw("<hr>\n"), HTML.DIV({
    "class": "row"
  }, "\n  ", HTML.DIV({
    "class": "col-md-12"
  }, "\n    ", HTML.Raw('<input type="checkbox" id="filterByReassessmentStatus">'), "Only those signed up?", HTML.Raw("<br>"), "\n    ", HTML.Raw('<button class="btn btn-primary" id="assignQuiz">Assign</button>'), "\n    ", HTML.Raw('<button class="btn btn-warning" id="resetQuiz">Reset</button>'), "\n    ", Spacebars.include(view.lookupTemplate("classRoster")), "\n\n  "), "\n  ", HTML.DIV({
    "class": "col-md-4"
  }, "\n    ", Blaze.If(function() {
    return Spacebars.call(view.lookup("quizzesAssigned"));
  }, function() {
    return [ "\n    QuizzesAssigned to:\n    ", Blaze.Each(function() {
      return Spacebars.call(view.lookup("quizzesAssigned"));
    }, function() {
      return [ "\n    ", HTML.P(Blaze.View("lookup:.", function() {
        return Spacebars.mustache(view.lookup("."));
      })), "\n    " ];
    }), "\n    " ];
  }), "\n  "), "\n") ];
}));

Template.__checkName("classRoster");
Template["classRoster"] = new Template("Template.classRoster", (function() {
  var view = this;
  return HTML.DIV({
    "class": "row"
  }, "\n   ", HTML.DIV({
    "class": "row"
  }, "\n   ", HTML.DIV({
    "class": "col-md-4"
  }, "\n   ", HTML.SELECT({
    name: "date",
    id: "selectDate",
    "class": "form-control"
  }, "\n   ", HTML.Raw('<option value="" selected="selected"></option>'), "\n   ", Blaze.Each(function() {
    return Spacebars.call(view.lookup("reassessmentFoundDay"));
  }, function() {
    return [ "\n   ", HTML.OPTION({
      value: function() {
        return Spacebars.mustache(view.lookup("."));
      }
    }, Blaze.View("lookup:.", function() {
      return Spacebars.mustache(view.lookup("."));
    })), "\n\n   " ];
  }), "\n   ")), "\n   "), "\n   ", HTML.DIV({
    "class": "col-md-12",
    id: "reassessmentStudentList"
  }, "\n     ", HTML.TABLE({
    id: "reassessmentStudents"
  }, "\n       ", Blaze.Each(function() {
    return Spacebars.call(view.lookup("reassessmentStudent"));
  }, function() {
    return [ "\n       ", HTML.TR(HTML.TD(HTML.INPUT({
      type: "checkbox",
      "class": "selectToAddQuiz"
    })), HTML.TD(Blaze.View("lookup:getName", function() {
      return Spacebars.mustache(view.lookup("getName"), Spacebars.dot(view.lookup("."), "user"));
    })), HTML.TD(Blaze.View("lookup:..unit", function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("."), "unit"));
    }), "^", Blaze.View("lookup:..standard", function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("."), "standard"));
    }), "-", Blaze.View("lookup:..grade", function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("."), "grade"));
    }), "-", Blaze.View("lookup:..time", function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("."), "time"));
    }))), "\n       " ];
  }), "\n     "), "\n   "), "\n ");
}));

Template.__checkName("quizzesViewAll");
Template["quizzesViewAll"] = new Template("Template.quizzesViewAll", (function() {
  var view = this;
  return [ HTML.DIV({
    "class": "row"
  }, "\n ", HTML.DIV({
    "class": "col-md-8"
  }, "\n   Pending Quizzes:\n   ", HTML.TABLE({
    "class": "table"
  }, "\n    ", HTML.TR("\n      ", HTML.TD("Date"), "\n      ", HTML.TD("Name"), "\n      ", HTML.TD("Course"), "\n      ", HTML.TD("Standards"), "\n      ", HTML.TD("Active?"), "\n      ", HTML.TD("Completed?"), "\n    "), "\n    ", Blaze.Each(function() {
    return Spacebars.call(view.lookup("incompleteQuizzes"));
  }, function() {
    return [ "\n    ", HTML.TR("\n      ", HTML.TD(HTML.A({
      href: function() {
        return [ "/quizzes/view/", Spacebars.mustache(view.lookup("_id")) ];
      }
    }, Blaze.View("lookup:shortenDate", function() {
      return Spacebars.mustache(view.lookup("shortenDate"), view.lookup("created"));
    }))), "\n      ", HTML.TD(Blaze.View("lookup:getUsername", function() {
      return Spacebars.mustache(view.lookup("getUsername"), view.lookup("user"));
    })), "\n      ", HTML.TD(Blaze.View("lookup:courses", function() {
      return Spacebars.mustache(view.lookup("courses"));
    })), "\n      ", HTML.TD(Blaze.View("lookup:standards", function() {
      return Spacebars.mustache(view.lookup("standards"));
    })), "\n      ", HTML.TD(HTML.INPUT(HTML.Attrs({
      type: "checkbox",
      "class": "quizVisible"
    }, function() {
      return Spacebars.attrMustache(view.lookup("active"));
    }))), "\n      ", HTML.TD(HTML.BUTTON({
      "class": "btn btn-primary quizCompleted"
    }, "Completed"), HTML.BUTTON({
      "class": "btn btn-danger quizDelete"
    }, "Delete")), "\n    "), "\n    " ];
  }), "\n   "), "\n "), "\n"), "\n\n\n ", HTML.DIV({
    "class": "row"
  }, "\n   ", HTML.DIV({
    "class": "col-md-8"
  }, "\n     Completed Quizzes:\n ", HTML.TABLE({
    "class": "table"
  }, "\n  ", HTML.TR("\n    ", HTML.TD("Date"), "\n    ", HTML.TD("Name"), "\n    ", HTML.TD("Course"), "\n    ", HTML.TD("Standards"), "\n    ", HTML.TD("Active?"), "\n    ", HTML.TD("Completed?"), "\n  "), "\n  ", Blaze.Each(function() {
    return Spacebars.call(view.lookup("completeQuizzes"));
  }, function() {
    return [ "\n  ", HTML.TR("\n    ", HTML.TD(HTML.A({
      href: function() {
        return [ "/quizzes/view/", Spacebars.mustache(view.lookup("_id")) ];
      }
    }, Blaze.View("lookup:shortenDate", function() {
      return Spacebars.mustache(view.lookup("shortenDate"), view.lookup("created"));
    }))), "\n    ", HTML.TD(Blaze.View("lookup:getUsername", function() {
      return Spacebars.mustache(view.lookup("getUsername"), view.lookup("user"));
    })), "\n    ", HTML.TD(Blaze.View("lookup:courses", function() {
      return Spacebars.mustache(view.lookup("courses"));
    })), "\n    ", HTML.TD(Blaze.View("lookup:standards", function() {
      return Spacebars.mustache(view.lookup("standards"));
    })), "\n    ", HTML.TD(HTML.INPUT(HTML.Attrs({
      type: "checkbox",
      "class": "quizVisible"
    }, function() {
      return Spacebars.attrMustache(view.lookup("active"));
    }))), "\n    ", HTML.TD(HTML.BUTTON({
      "class": "btn btn-primary quizNotCompleted"
    }, "Not Complete"), HTML.BUTTON({
      "class": "btn btn-danger quizDelete"
    }, "Delete")), "\n  "), "\n  " ];
  }), "\n "), "\n"), "\n") ];
}));

Template.__checkName("quizView");
Template["quizView"] = new Template("Template.quizView", (function() {
  var view = this;
  return HTML.DIV({
    id: "quizBackground"
  }, "\n\n", Blaze.If(function() {
    return Spacebars.call(view.lookup("quizVisible"));
  }, function() {
    return [ "\n ", Blaze.If(function() {
      return Spacebars.call(view.lookup("adminView"));
    }, function() {
      return "\n This quiz is not yet visible to the student.\n ";
    }), "\n ", HTML.DIV({
      "class": "row"
    }, "\n   ", HTML.DIV({
      "class": "col-md-4 quizHeading"
    }, "\n     ", Blaze.View("lookup:getUsername", function() {
      return Spacebars.mustache(view.lookup("getUsername"), view.lookup("user"));
    }), "\n   "), "\n   ", HTML.DIV({
      "class": "col-md-4 quizHeading"
    }, "\n     Course(s): ", Blaze.View("lookup:courses", function() {
      return Spacebars.mustache(view.lookup("courses"));
    }), "\n   "), "\n   ", HTML.DIV({
      "class": "col-md-4 quizHeading"
    }, "\n     Standard(s): ", Blaze.View("lookup:standards", function() {
      return Spacebars.mustache(view.lookup("standards"));
    }), "\n   "), "\n "), "\n", Blaze.Each(function() {
      return Spacebars.call(view.lookup("questions"));
    }, function() {
      return [ "\n", Spacebars.include(view.lookupTemplate("quizQuestionView")), "\n" ];
    }), "\n" ];
  }), "\n", Blaze.Unless(function() {
    return Spacebars.call(view.lookup("quizVisible"));
  }, function() {
    return [ "\n", HTML.DIV({
      "class": "row"
    }, "\n ", HTML.DIV({
      "class": "col-md-12 text-center"
    }, "\n   ", HTML.H3("This quiz is not yet visible. Check back soon!"), "\n "), "\n"), "\n" ];
  }), "\n");
}));

Template.__checkName("quizQuestionView");
Template["quizQuestionView"] = new Template("Template.quizQuestionView", (function() {
  var view = this;
  return [ HTML.DIV({
    "class": "row quizQuestionDisplay"
  }, "\n ", HTML.DIV({
    "class": "col-md-12 question"
  }, "\n   ", Blaze.View("lookup:text", function() {
    return Spacebars.makeRaw(Spacebars.mustache(view.lookup("text")));
  }), "\n "), "\n"), "\n", Blaze.If(function() {
    return Spacebars.call(view.lookup("answerVisible"));
  }, function() {
    return [ "\n", HTML.DIV({
      "class": "row quizAnswerDisplay"
    }, "\n ", HTML.DIV({
      "class": "col-md-12 question"
    }, "\n   Answer: ", HTML.getTag("ans")(Blaze.View("lookup:answer", function() {
      return Spacebars.makeRaw(Spacebars.mustache(view.lookup("answer")));
    })), "\n "), "\n"), "\n" ];
  }) ];
}));

Template.__checkName("quizzesViewMine");
Template["quizzesViewMine"] = new Template("Template.quizzesViewMine", (function() {
  var view = this;
  return [ HTML.DIV({
    "class": "row"
  }, "\n ", HTML.DIV({
    "class": "col-md-8"
  }, "\n   Pending Quizzes:\n   ", HTML.TABLE({
    "class": "table"
  }, "\n    ", HTML.TR("\n      ", HTML.TD("Date"), "\n      ", HTML.TD("Name"), "\n      ", HTML.TD("Course"), "\n      ", HTML.TD("Standards"), "\n\n    "), "\n    ", Blaze.Each(function() {
    return Spacebars.call(view.lookup("incompleteQuizzes"));
  }, function() {
    return [ "\n    ", HTML.TR("\n      ", HTML.TD(HTML.A({
      href: function() {
        return [ "/quizzes/view/", Spacebars.mustache(view.lookup("_id")) ];
      }
    }, Blaze.View("lookup:shortenDate", function() {
      return Spacebars.mustache(view.lookup("shortenDate"), view.lookup("created"));
    }), " - View Quiz")), "\n      ", HTML.TD(Blaze.View("lookup:getUsername", function() {
      return Spacebars.mustache(view.lookup("getUsername"), view.lookup("user"));
    })), "\n      ", HTML.TD(Blaze.View("lookup:courses", function() {
      return Spacebars.mustache(view.lookup("courses"));
    })), "\n      ", HTML.TD(Blaze.View("lookup:standards", function() {
      return Spacebars.mustache(view.lookup("standards"));
    })), "\n\n    "), "\n    " ];
  }), "\n   "), "\n "), "\n"), "\n\n\n ", HTML.DIV({
    "class": "row"
  }, "\n   ", HTML.DIV({
    "class": "col-md-8"
  }, "\n     Completed Quizzes:\n ", HTML.TABLE({
    "class": "table"
  }, "\n  ", HTML.TR("\n    ", HTML.TD("Date"), "\n    ", HTML.TD("Name"), "\n    ", HTML.TD("Course"), "\n    ", HTML.TD("Standards"), "\n\n  "), "\n  ", Blaze.Each(function() {
    return Spacebars.call(view.lookup("completeQuizzes"));
  }, function() {
    return [ "\n  ", HTML.TR("\n    ", HTML.TD(HTML.A({
      href: function() {
        return [ "/quizzes/view/", Spacebars.mustache(view.lookup("_id")) ];
      }
    }, Blaze.View("lookup:shortenDate", function() {
      return Spacebars.mustache(view.lookup("shortenDate"), view.lookup("created"));
    }), " - View Quiz")), "\n    ", HTML.TD(Blaze.View("lookup:getUsername", function() {
      return Spacebars.mustache(view.lookup("getUsername"), view.lookup("user"));
    })), "\n    ", HTML.TD(Blaze.View("lookup:courses", function() {
      return Spacebars.mustache(view.lookup("courses"));
    })), "\n    ", HTML.TD(Blaze.View("lookup:standards", function() {
      return Spacebars.mustache(view.lookup("standards"));
    })), "\n\n  "), "\n  " ];
  }), "\n "), "\n"), "\n") ];
}));

Template.__checkName("courseUnitStandard");
Template["courseUnitStandard"] = new Template("Template.courseUnitStandard", (function() {
  var view = this;
  return HTML.DIV({
    "class": "form-inline"
  }, "\n\n", HTML.DIV({
    "class": "form-group"
  }, "\n", HTML.Raw('<label class="control-label">Course:</label>'), "\n", HTML.SELECT({
    name: "course",
    "class": "courseSelect form-control",
    id: "courseSelectCourse"
  }, "\n", HTML.Raw('<option value=""></option>'), "\n", Blaze.Each(function() {
    return Spacebars.call(view.lookup("courses"));
  }, function() {
    return [ "\n", HTML.OPTION({
      value: function() {
        return Spacebars.mustache(view.lookup("."));
      }
    }, Blaze.View("lookup:.", function() {
      return Spacebars.mustache(view.lookup("."));
    })), "\n" ];
  }), "\n\n"), "\n "), "\n\n ", HTML.DIV({
    "class": "form-group"
  }, "\n ", HTML.Raw('<label class="control-label">Unit:</label>'), "\n\n ", HTML.SELECT({
    name: "unit",
    "class": "courseSelect form-control",
    id: "courseSelectUnit"
  }, "\n", HTML.Raw('<option value=""></option>'), "\n ", Blaze.Each(function() {
    return Spacebars.call(view.lookup("units"));
  }, function() {
    return [ "\n ", HTML.OPTION({
      value: function() {
        return Spacebars.mustache(view.lookup("."));
      }
    }, Blaze.View("lookup:.", function() {
      return Spacebars.mustache(view.lookup("."));
    })), "\n " ];
  }), "\n\n\n "), "\n  "), "\n\n\n ", HTML.DIV({
    "class": "form-group"
  }, "\n ", HTML.Raw('<label class="control-label">Standard:</label>'), "\n\n ", HTML.SELECT({
    name: "standard",
    "class": "courseSelect  form-control",
    id: "courseSelectStandard"
  }, "\n ", HTML.Raw('<option value=""></option>'), "\n ", Blaze.Each(function() {
    return Spacebars.call(view.lookup("standards"));
  }, function() {
    return [ "\n ", HTML.OPTION({
      value: function() {
        return Spacebars.mustache(view.lookup("."));
      }
    }, Blaze.View("lookup:.", function() {
      return Spacebars.mustache(view.lookup("."));
    })), "\n " ];
  }), "\n\n "), "\n  "), "\n ");
}));

Template.__checkName("desmosView");
Template["desmosView"] = new Template("Template.desmosView", (function() {
  var view = this;
  return HTML.Raw('<div class="row">\n    <div class="col-md-6">\n  <div class="desmos-container">\n\n  </div>\n  <input type="text" name="desmos-input" id="desmos-input">\n </div>\n</div>');
}));

Template.__checkName("desmos");
Template["desmos"] = new Template("Template.desmos", (function() {
  var view = this;
  return [ "Desmos:\n  ", Spacebars.include(view.lookupTemplate("desmosView")) ];
}));

}).call(this);
