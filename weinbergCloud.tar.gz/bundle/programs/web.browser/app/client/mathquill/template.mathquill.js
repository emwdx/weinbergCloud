(function(){
Template.__checkName("mathQuillDemo");
Template["mathQuillDemo"] = new Template("Template.mathQuillDemo", (function() {
  var view = this;
  return HTML.Raw('<p>\n  <h5>Enter the question text below:</h5>\n   <span class="mathquill-textbox" id="mqQuestionText"></span>\n</p>\n\n<p>\n  <h5>Enter the answer text below:</h5>\n   <span class="mathquill-textbox" id="mqQuestionAnswer"></span>\n</p>');
}));

}).call(this);
