(function(){
Template.__checkName("gamesOfChance");
Template["gamesOfChance"] = new Template("Template.gamesOfChance", (function() {
  var view = this;
  return [ HTML.H1("You currently have $", Blaze.View("lookup:numOfWB", function() {
    return Spacebars.mustache(view.lookup("numOfWB"));
  }), " of WeinbergCash."), HTML.Raw('\n<span class="text-info">Note: The current real world value of $1.00 in WeinbergCash is 0 RMB.</span>\n<hr>\nYou can win more by choosing to make one of the wagers below:\n '), HTML.P("\n", HTML.Raw("<h3>Your bet:</h3>"), "    \n", HTML.INPUT({
    type: "number",
    id: "myBet",
    placeholder: "How much do you want to bet?",
    min: "0.00",
    max: function() {
      return Spacebars.mustache(view.lookup("numOfWB"));
    },
    step: "0.001"
  }), "    \n    \n    "), HTML.Raw('\n    <p>\n<button class="btn btn-primary" id="bet2x">50% probability of winning 2x your bet<br>Mr. Weinberg taxes your winnings 5%</button>\n<button class="btn btn-primary" id="bet3x">30% probability of winning 3x your bet<br>Mr. Weinberg taxes your winnings 2%</button>\n<button class="btn btn-primary" id="bet4x">25% probability of winning 4x your bet<br> No Weinberg tax!</button>\n    </p>') ];
}));

Template.__checkName("allWBCTotals");
Template["allWBCTotals"] = new Template("Template.allWBCTotals", (function() {
  var view = this;
  return HTML.DIV({
    "class": "span6 offset3"
  }, HTML.Raw('\n<p class="text-center">WeinbergCash Totals:</p>\n'), HTML.TABLE({
    "class": "table "
  }, "\n\n", Blaze.Each(function() {
    return Spacebars.call(view.lookup("WBProfiles"));
  }, function() {
    return [ "\n", HTML.TR(HTML.TD(HTML.H3(Blaze.View("lookup:profile.realName", function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("profile"), "realName"));
    }))), HTML.TD(HTML.H3("$", Blaze.View("lookup:numOfWB", function() {
      return Spacebars.mustache(view.lookup("numOfWB"));
    })))), "\n" ];
  }), "\n"), "\n");
}));

}).call(this);
