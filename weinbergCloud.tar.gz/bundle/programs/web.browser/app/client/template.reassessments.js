(function(){
Template.__checkName("reassessSignUp");
Template["reassessSignUp"] = new Template("Template.reassessSignUp", (function() {
  var view = this;
  return [ HTML.Raw('<div class="row">\n<div class="col-md-4 col-md-offset-4">\n<h3 id="myModalLabel">Sign-up for Reassessment:</h3>\n\n</div>\n\n</div>\n\n\n\n'), HTML.FORM({
    "class": "form-horizontal"
  }, "\n", HTML.DIV({
    "class": "row"
  }, "\n\n", HTML.DIV({
    "class": "control-group col-md-4"
  }, "\n", HTML.Raw('<label class="control-label">Course:</label>'), "\n", HTML.DIV({
    "class": "controls"
  }, "\n", HTML.SELECT({
    name: "course",
    "class": "reassessSelect form-control",
    id: "reassessSelectCourse"
  }, "\n\n", Blaze.Each(function() {
    return Spacebars.call(view.lookup("reassessCourse"));
  }, function() {
    return [ "\n", HTML.OPTION({
      value: function() {
        return Spacebars.mustache(view.lookup("."));
      }
    }, Blaze.View("lookup:.", function() {
      return Spacebars.mustache(view.lookup("."));
    })), "\n" ];
  }), "\n\n"), "\n "), "\n "), "\n\n", Blaze.If(function() {
    return Spacebars.call(view.lookup("hasEnoughCredits"));
  }, function() {
    return [ "\n", HTML.DIV({
      "class": "control-group col-md-4"
    }, "\n", HTML.LABEL({
      "class": "control-label"
    }, "Unit:"), "\n", HTML.DIV({
      "class": "controls"
    }, "\n", HTML.SELECT({
      name: "unit",
      "class": "reassessSelect form-control"
    }, "\n", HTML.OPTION({
      value: "0",
      selected: "selected"
    }), "\n", Blaze.Each(function() {
      return Spacebars.call(view.lookup("reassessCourseUnits"));
    }, function() {
      return [ "\n", HTML.OPTION({
        value: function() {
          return Spacebars.mustache(view.lookup("."));
        }
      }, Blaze.View("lookup:.", function() {
        return Spacebars.mustache(view.lookup("."));
      })), "\n" ];
    }), "\n\n\n"), "\n "), "\n  "), "\n\n", HTML.DIV({
      "class": "control-group col-md-4"
    }, "\n", HTML.LABEL({
      "class": "control-label"
    }, "Standard:"), "\n", HTML.DIV({
      "class": "controls"
    }, "\n", HTML.SELECT({
      name: "standard",
      "class": "reassessSelect form-control"
    }, "\n", HTML.OPTION({
      value: "0",
      selected: "selected"
    }), "\n", Blaze.Each(function() {
      return Spacebars.call(view.lookup("reassessCourseStandards"));
    }, function() {
      return [ "\n", HTML.OPTION({
        value: function() {
          return Spacebars.mustache(view.lookup("."));
        }
      }, Blaze.View("lookup:.", function() {
        return Spacebars.mustache(view.lookup("."));
      })), "\n" ];
    }), "\n\n"), "\n "), "\n"), "\n" ];
  }), "\n\n\n"), "\n", Blaze.If(function() {
    return Spacebars.call(view.lookup("hasEnoughCredits"));
  }, function() {
    return [ "\n", HTML.DIV({
      "class": "row"
    }, "\n", HTML.DIV({
      "class": "col-md-6 col-md-offset-3"
    }, "\n    ", Blaze.If(function() {
      return Spacebars.call(view.lookup("standardFound"));
    }, function() {
      return [ "\n    ", Spacebars.With(function() {
        return Spacebars.call(view.lookup("standardFound"));
      }, function() {
        return [ "\n    ", HTML.P(), "\n    ", HTML.P({
          "class": "text-center text-info"
        }, "\n    ", HTML.A({
          href: function() {
            return [ "/standards/view/", Spacebars.mustache(view.lookup("_id")), "/" ];
          }
        }, "\n   ", HTML.H4(" ", Blaze.View("lookup:course", function() {
          return Spacebars.mustache(view.lookup("course"));
        }), " Standard ", Blaze.View("lookup:unit", function() {
          return Spacebars.mustache(view.lookup("unit"));
        }), ".", Blaze.View("lookup:standard", function() {
          return Spacebars.mustache(view.lookup("standard"));
        }), ": ", Blaze.View("lookup:title", function() {
          return Spacebars.mustache(view.lookup("title"));
        }), " "), "\n    "), "\n    "), "\n    " ];
      }), "\n    " ];
    }), "\n  "), "\n"), "\n\n", HTML.DIV({
      "class": "row"
    }, "\n\n", HTML.DIV({
      "class": "control-group col-md-4"
    }, "\n", HTML.LABEL({
      "class": "control-label"
    }, " PowerSchool Grade on this Standard:"), "\n\n", HTML.DIV({
      "class": "controls"
    }, "\n", HTML.SELECT({
      name: "grade",
      "class": "reassessSelect form-control"
    }, "\n", HTML.OPTION({
      value: "0",
      selected: "selected"
    }), "\n", HTML.OPTION({
      value: "5"
    }, "5"), "\n", HTML.OPTION({
      value: "6"
    }, "6"), "\n", HTML.OPTION({
      value: "7"
    }, "7"), "\n", HTML.OPTION({
      value: "8"
    }, "8"), "\n", HTML.OPTION({
      value: "9"
    }, "9"), "\n"), "\n "), "\n  "), "\n\n\n  ", HTML.DIV({
      "class": "control-group col-md-4"
    }, "\n    ", HTML.LABEL({
      "class": "control-label"
    }, "Time:"), "\n", HTML.DIV({
      "class": "controls"
    }, "\n", HTML.SELECT({
      name: "time",
      "class": "reassessSelect form-control"
    }, "\n", HTML.OPTION({
      value: "0",
      selected: "selected"
    }), "\n", HTML.OPTION({
      value: "Before School"
    }, "Before School"), "\n", HTML.OPTION({
      value: "During Lunch"
    }, "During Lunch"), "\n", HTML.OPTION({
      value: "In-Class Quiz"
    }, "In-Class Quiz"), "\n", HTML.OPTION({
      value: "After School"
    }, "After School"), "\n", HTML.OPTION({
      value: "Block D or G"
    }, "Block D or G"), "\n\n\n"), "\n "), "\n "), "\n\n  ", HTML.DIV({
      "class": "control-group col-md-4"
    }, "\n    ", HTML.LABEL({
      "class": "control-label"
    }, "Day"), "\n", HTML.DIV({
      "class": "controls"
    }, "\n", HTML.SELECT({
      name: "date",
      "class": "form-control"
    }, "\n", Blaze.If(function() {
      return Spacebars.call(view.lookup("isWeekend"));
    }, function() {
      return [ "\n", HTML.OPTION({
        value: function() {
          return Spacebars.mustache(Spacebars.dot(view.lookup("daysObject"), "a"));
        }
      }, Blaze.View("lookup:daysObject.a", function() {
        return Spacebars.mustache(Spacebars.dot(view.lookup("daysObject"), "a"));
      })), "\n" ];
    }), "\n", HTML.OPTION({
      value: function() {
        return Spacebars.mustache(Spacebars.dot(view.lookup("daysObject"), "b"));
      }
    }, Blaze.View("lookup:daysObject.b", function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("daysObject"), "b"));
    })), "\n", HTML.OPTION({
      value: function() {
        return Spacebars.mustache(Spacebars.dot(view.lookup("daysObject"), "c"));
      }
    }, Blaze.View("lookup:daysObject.c", function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("daysObject"), "c"));
    })), "\n", HTML.OPTION({
      value: function() {
        return Spacebars.mustache(Spacebars.dot(view.lookup("daysObject"), "d"));
      }
    }, " ", Blaze.View("lookup:daysObject.d", function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("daysObject"), "d"));
    })), "\n", HTML.OPTION({
      value: function() {
        return Spacebars.mustache(Spacebars.dot(view.lookup("daysObject"), "e"));
      }
    }, " ", Blaze.View("lookup:daysObject.e", function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("daysObject"), "e"));
    })), "\n", HTML.OPTION({
      value: function() {
        return Spacebars.mustache(Spacebars.dot(view.lookup("daysObject"), "f"));
      }
    }, Blaze.View("lookup:daysObject.f", function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("daysObject"), "f"));
    })), "\n\n"), "\n\n "), "\n "), "\n"), "\n\n" ];
  }), "\n\n", HTML.DIV({
    "class": "row"
  }, "\n", HTML.Raw('<div class="col-md-4"></div>'), "\n    ", HTML.SPAN({
    "class": "text-left"
  }, Blaze.View("lookup:currentCourse", function() {
    return Spacebars.mustache(view.lookup("currentCourse"));
  }), " Reassessment Credits: ", Spacebars.include(view.lookupTemplate("myCreditsBadge"))), "\n", HTML.DIV({
    "class": "col-md-4"
  }, "\n    ", Blaze.If(function() {
    return Spacebars.call(view.lookup("hasEnoughCredits"));
  }, function() {
    return [ "\n     ", Blaze.Unless(function() {
      return Spacebars.call(view.lookup("isSubmittingReassessment"));
    }, function() {
      return [ "\n    ", HTML.BUTTON({
        "class": "btn btn-primary",
        id: "signUpRetakes"
      }, "Sign-Up"), "\n    " ];
    }), "\n    " ];
  }), "\n"), "\n    ", Blaze.If(function() {
    return Spacebars.call(view.lookup("isSubmittingReassessment"));
  }, function() {
    return [ "\n    ", HTML.H4("Submitting reassessment...Please wait."), "\n    ", Spacebars.include(view.lookupTemplate("spinner")), "\n    " ];
  }), "\n"), "\n\n"), "\n\n\n", Blaze.Unless(function() {
    return Spacebars.call(view.lookup("hasEnoughCredits"));
  }, function() {
    return [ "\n", HTML.DIV({
      "class": "row"
    }, "\n", HTML.DIV({
      id: "notEnoughCredits col-md-6 col-md-offset-3"
    }, "\n    ", HTML.SPAN({
      "class": "text-error"
    }, "You do not have enough credits for this reassessment. How do you earn more?"), "\n    ", HTML.UL("\n    ", HTML.LI("Show Mr. Weinberg practice questions you have completed for this standard since your last assessment. "), "\n    ", HTML.LI("See Mr. Weinberg for tutoring."), "\n    ", HTML.LI("Show Mr. Weinberg independent work you have done during class related to this standard since your last assessment."), "\n    "), "\n"), "\n"), "\n" ];
  }) ];
}));

Template.__checkName("reassessEdit");
Template["reassessEdit"] = new Template("Template.reassessEdit", (function() {
  var view = this;
  return [ HTML.Raw('<div class="row">\n<div class="col-md-6 col-md-offset-3">\n<h3 id="myModalLabel">Edit Reassessment:</h3>\n\n</div>\n\n</div>\n\n'), HTML.FORM({
    "class": "form-horizontal",
    id: "reassessEditForm"
  }, "\n ", Spacebars.With(function() {
    return Spacebars.call(view.lookup("selectedReassessment"));
  }, function() {
    return [ "\n", HTML.DIV({
      "class": "row"
    }, "\n\n", HTML.DIV({
      "class": "control-group col-md-4"
    }, "\n", HTML.LABEL({
      "class": "control-label"
    }, "Course:"), "\n", HTML.DIV({
      "class": "controls"
    }, "\n", HTML.SELECT({
      name: "course",
      "class": "reassessEditSelect form-control"
    }, "\n\n\n", HTML.OPTION({
      value: function() {
        return Spacebars.mustache(view.lookup("course"));
      },
      selected: ""
    }, Blaze.View("lookup:course", function() {
      return Spacebars.mustache(view.lookup("course"));
    })), "\n\n\n"), "\n "), "\n "), "\n\n\n", HTML.DIV({
      "class": "control-group col-md-4"
    }, "\n", HTML.LABEL({
      "class": "control-label"
    }, "Unit:"), "\n", HTML.DIV({
      "class": "controls"
    }, "\n", HTML.SELECT({
      name: "unit",
      "class": "reassessEditSelect form-control",
      value: function() {
        return Spacebars.mustache(view.lookup("unit"));
      }
    }, "\n", HTML.OPTION({
      value: "0"
    }), "\n\n", Blaze.Each(function() {
      return Spacebars.call(view.lookup("reassessCourseUnits"));
    }, function() {
      return [ "\n", HTML.OPTION({
        value: function() {
          return Spacebars.mustache(view.lookup("."));
        }
      }, Blaze.View("lookup:.", function() {
        return Spacebars.mustache(view.lookup("."));
      })), "\n" ];
    }), "\n\n\n"), "\n "), "\n  "), "\n\n", HTML.DIV({
      "class": "control-group col-md-4"
    }, "\n", HTML.LABEL({
      "class": "control-label"
    }, "Standard:"), "\n", HTML.DIV({
      "class": "controls"
    }, "\n", HTML.SELECT({
      name: "standard",
      "class": "reassessEditSelect form-control"
    }, "\n", HTML.OPTION({
      value: "0"
    }), "\n\n", Blaze.Each(function() {
      return Spacebars.call(view.lookup("reassessCourseStandards"));
    }, function() {
      return [ "\n", HTML.OPTION({
        value: function() {
          return Spacebars.mustache(view.lookup("."));
        }
      }, Blaze.View("lookup:.", function() {
        return Spacebars.mustache(view.lookup("."));
      })), "\n" ];
    }), "\n\n"), "\n "), "\n"), "\n\n"), "\n", HTML.DIV({
      "class": "row"
    }, "\n", HTML.DIV({
      "class": "col-md-6 col-md-offset-3"
    }, "\n    ", Blaze.If(function() {
      return Spacebars.call(view.lookup("standardFound"));
    }, function() {
      return [ "\n    ", Spacebars.With(function() {
        return Spacebars.call(view.lookup("standardFound"));
      }, function() {
        return [ "\n    ", HTML.P(), "\n    ", HTML.P({
          "class": "text-center text-info"
        }, "\n    ", HTML.A({
          href: function() {
            return [ "/standards/view/", Spacebars.mustache(view.lookup("_id")), "/" ];
          }
        }, "\n   ", HTML.H4(" ", Blaze.View("lookup:course", function() {
          return Spacebars.mustache(view.lookup("course"));
        }), " Standard ", Blaze.View("lookup:unit", function() {
          return Spacebars.mustache(view.lookup("unit"));
        }), ".", Blaze.View("lookup:standard", function() {
          return Spacebars.mustache(view.lookup("standard"));
        }), ": ", Blaze.View("lookup:title", function() {
          return Spacebars.mustache(view.lookup("title"));
        }), " "), "\n    "), "\n    "), "\n    " ];
      }), "\n    " ];
    }), "\n  "), "\n"), "\n\n", HTML.DIV({
      "class": "row"
    }, "\n\n", HTML.DIV({
      "class": "control-group col-md-4"
    }, "\n", HTML.LABEL({
      "class": "control-label"
    }, " Current Grade on this Standard:"), "\n\n", HTML.DIV({
      "class": "controls"
    }, "\n", HTML.SELECT({
      name: "grade",
      "class": "reassessSelect form-control"
    }, "\n", HTML.OPTION({
      value: "0",
      selected: "selected"
    }), "\n", HTML.OPTION(HTML.Attrs({
      value: "5"
    }, function() {
      return Spacebars.attrMustache(view.lookup("selectedIf"), view.lookup("grade"), "5");
    }), "5"), "\n", HTML.OPTION(HTML.Attrs({
      value: "6"
    }, function() {
      return Spacebars.attrMustache(view.lookup("selectedIf"), view.lookup("grade"), "6");
    }), "6"), "\n", HTML.OPTION(HTML.Attrs({
      value: "7"
    }, function() {
      return Spacebars.attrMustache(view.lookup("selectedIf"), view.lookup("grade"), "7");
    }), "7"), "\n", HTML.OPTION(HTML.Attrs({
      value: "8"
    }, function() {
      return Spacebars.attrMustache(view.lookup("selectedIf"), view.lookup("grade"), "8");
    }), "8"), "\n", HTML.OPTION(HTML.Attrs({
      value: "9"
    }, function() {
      return Spacebars.attrMustache(view.lookup("selectedIf"), view.lookup("grade"), "9");
    }), "9"), "\n"), "\n "), "\n  "), "\n\n\n  ", HTML.DIV({
      "class": "control-group col-md-4"
    }, "\n    ", HTML.LABEL({
      "class": "control-label"
    }, "Time:"), "\n", HTML.DIV({
      "class": "controls"
    }, "\n", HTML.SELECT({
      name: "time",
      "class": "reassessSelect form-control"
    }, "\n", HTML.OPTION({
      value: "0"
    }), "\n", HTML.OPTION(HTML.Attrs({
      value: "Before School"
    }, function() {
      return Spacebars.attrMustache(view.lookup("selectedIf"), view.lookup("time"), "Before School");
    }), "Before School"), "\n", HTML.OPTION(HTML.Attrs({
      value: "During Lunch"
    }, function() {
      return Spacebars.attrMustache(view.lookup("selectedIf"), view.lookup("time"), "During Lunch");
    }), "During Lunch"), "\n", HTML.OPTION(HTML.Attrs({
      value: "In-Class Quiz"
    }, function() {
      return Spacebars.attrMustache(view.lookup("selectedIf"), view.lookup("time"), "In-Class Quiz");
    }), "In-Class Quiz"), "\n", HTML.OPTION(HTML.Attrs({
      value: "After School"
    }, function() {
      return Spacebars.attrMustache(view.lookup("selectedIf"), view.lookup("time"), "After School");
    }), "After School"), "\n", HTML.OPTION(HTML.Attrs({
      value: "Block D or G"
    }, function() {
      return Spacebars.attrMustache(view.lookup("selectedIf"), view.lookup("time"), "Block D or G");
    }), "Block D or G"), "\n\n\n"), "\n "), "\n "), "\n\n  ", HTML.DIV({
      "class": "control-group col-md-4"
    }, "\n    ", HTML.LABEL({
      "class": "control-label"
    }, "Day"), "\n", HTML.DIV({
      "class": "controls"
    }, "\n", HTML.SELECT({
      name: "date",
      "class": "form-control"
    }, "\n", Blaze.If(function() {
      return Spacebars.call(view.lookup("isWeekend"));
    }, function() {
      return [ "\n", HTML.OPTION(HTML.Attrs({
        value: function() {
          return Spacebars.mustache(Spacebars.dot(view.lookup("daysObject"), "a"));
        }
      }, function() {
        return Spacebars.attrMustache(view.lookup("selectedIf"), view.lookup("day"), Spacebars.dot(view.lookup("daysObject"), "a"));
      }), Blaze.View("lookup:daysObject.a", function() {
        return Spacebars.mustache(Spacebars.dot(view.lookup("daysObject"), "a"));
      })), "\n" ];
    }), "\n", HTML.OPTION(HTML.Attrs({
      value: function() {
        return Spacebars.mustache(Spacebars.dot(view.lookup("daysObject"), "b"));
      }
    }, function() {
      return Spacebars.attrMustache(view.lookup("selectedIf"), view.lookup("day"), Spacebars.dot(view.lookup("daysObject"), "b"));
    }), Blaze.View("lookup:daysObject.b", function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("daysObject"), "b"));
    })), "\n", HTML.OPTION(HTML.Attrs({
      value: function() {
        return Spacebars.mustache(Spacebars.dot(view.lookup("daysObject"), "c"));
      }
    }, function() {
      return Spacebars.attrMustache(view.lookup("selectedIf"), view.lookup("day"), Spacebars.dot(view.lookup("daysObject"), "c"));
    }), Blaze.View("lookup:daysObject.c", function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("daysObject"), "c"));
    })), "\n", HTML.OPTION(HTML.Attrs({
      value: function() {
        return Spacebars.mustache(Spacebars.dot(view.lookup("daysObject"), "d"));
      }
    }, function() {
      return Spacebars.attrMustache(view.lookup("selectedIf"), view.lookup("day"), Spacebars.dot(view.lookup("daysObject"), "d"));
    }), " ", Blaze.View("lookup:daysObject.d", function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("daysObject"), "d"));
    })), "\n", HTML.OPTION(HTML.Attrs({
      value: function() {
        return Spacebars.mustache(Spacebars.dot(view.lookup("daysObject"), "e"));
      }
    }, function() {
      return Spacebars.attrMustache(view.lookup("selectedIf"), view.lookup("day"), Spacebars.dot(view.lookup("daysObject"), "e"));
    }), " ", Blaze.View("lookup:daysObject.e", function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("daysObject"), "e"));
    })), "\n", HTML.OPTION(HTML.Attrs({
      value: function() {
        return Spacebars.mustache(Spacebars.dot(view.lookup("daysObject"), "f"));
      }
    }, function() {
      return Spacebars.attrMustache(view.lookup("selectedIf"), view.lookup("day"), Spacebars.dot(view.lookup("daysObject"), "f"));
    }), Blaze.View("lookup:daysObject.f", function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("daysObject"), "f"));
    })), "\n\n"), "\n\n "), "\n "), "\n"), "\n\n", HTML.DIV({
      "class": "row"
    }, "\n", HTML.DIV({
      "class": "col-md-4"
    }), "\n    ", HTML.SPAN({
      "class": "text-left"
    }, "Reassessment Credits: ", Spacebars.include(view.lookupTemplate("myCreditsBadge"))), "\n", HTML.DIV({
      "class": "col-md-4"
    }, "\n\n    ", HTML.BUTTON({
      "class": "btn btn-primary",
      id: "updateReassessment"
    }, "Update"), "\n\n"), "\n    ", Blaze.If(function() {
      return Spacebars.call(view.lookup("isSubmittingReassessment"));
    }, function() {
      return [ "\n    ", HTML.H4("Submitting reassessment...Please wait."), "\n    ", Spacebars.include(view.lookupTemplate("spinner")), "\n    " ];
    }), "\n"), "\n    " ];
  }), "\n") ];
}));

Template.__checkName("myReassessments");
Template["myReassessments"] = new Template("Template.myReassessments", (function() {
  var view = this;
  return HTML.DIV({
    "class": "span8 offset2"
  }, "\nMy upcoming reassessments:\n", HTML.TABLE({
    "class": "table table-condensed"
  }, "\n", Blaze.Each(function() {
    return Spacebars.call(view.lookup("upcomingReassessments"));
  }, function() {
    return [ "\n    ", Spacebars.include(view.lookupTemplate("reassessmentTemplate")), "\n" ];
  }), "\n", HTML.HR(), "\nMy completed reassessments:\n", Blaze.Each(function() {
    return Spacebars.call(view.lookup("completedReassessments"));
  }, function() {
    return [ "\n    ", Spacebars.include(view.lookupTemplate("reassessmentTemplate")), "\n" ];
  }), "\n"), "\n");
}));

Template.__checkName("reassessmentTemplate");
Template["reassessmentTemplate"] = new Template("Template.reassessmentTemplate", (function() {
  var view = this;
  return HTML.DIV({
    "class": "row reassessmentItem"
  }, "\n\n", HTML.DIV({
    "class": "col-md-4"
  }, "\n", Blaze.View("lookup:time", function() {
    return Spacebars.mustache(view.lookup("time"));
  }), " on ", Blaze.View("lookup:day", function() {
    return Spacebars.mustache(view.lookup("day"));
  }), "\n"), "\n", HTML.DIV({
    "class": "col-md-4"
  }, "\n    ", Blaze.View("lookup:course", function() {
    return Spacebars.mustache(view.lookup("course"));
  }), " Standard ", Blaze.View("lookup:unit", function() {
    return Spacebars.mustache(view.lookup("unit"));
  }), ".", Blaze.View("lookup:standard", function() {
    return Spacebars.mustache(view.lookup("standard"));
  }), "\n"), "\n", HTML.DIV({
    "class": "col-md-4"
  }, "\n", Blaze.Unless(function() {
    return Spacebars.call(view.lookup("completed"));
  }, function() {
    return [ "\n", HTML.BUTTON({
      "class": "btn cancelReassessment btn-danger reassessmentButtons"
    }, "Cancel"), HTML.BUTTON({
      "class": "btn editReassessment btn-info reassessmentButtons"
    }, "Edit"), "\n" ];
  }), "\n"), "\n");
}));

Template.__checkName("reassessmentAdminTemplate");
Template["reassessmentAdminTemplate"] = new Template("Template.reassessmentAdminTemplate", (function() {
  var view = this;
  return HTML.DIV({
    "class": function() {
      return [ "row reassessmentItem ", Spacebars.mustache(view.lookup("assigned")), " " ];
    }
  }, "\n", HTML.DIV({
    "class": "row"
  }, "\n", HTML.DIV({
    "class": "col-md-6"
  }, "\n", Blaze.View("lookup:time", function() {
    return Spacebars.mustache(view.lookup("time"));
  }), " on ", Blaze.View("lookup:day", function() {
    return Spacebars.mustache(view.lookup("day"));
  }), "\n", HTML.Raw("<br>"), "\n", Blaze.View("lookup:userName", function() {
    return Spacebars.mustache(view.lookup("userName"));
  }), "\n"), "\n", HTML.DIV({
    "class": "col-md-6"
  }, "\n\n\n    ", Blaze.View("lookup:course", function() {
    return Spacebars.mustache(view.lookup("course"));
  }), " Standard ", Blaze.View("lookup:unit", function() {
    return Spacebars.mustache(view.lookup("unit"));
  }), ".", Blaze.View("lookup:standard", function() {
    return Spacebars.mustache(view.lookup("standard"));
  }), "\n\n", HTML.Raw("<br>"), "\n    Current Grade: ", Blaze.View("lookup:grade", function() {
    return Spacebars.mustache(view.lookup("grade"));
  }), "\n\n"), "\n"), HTML.Raw('\n<div class="row">\n<div class="col-md-12">\n<button class="btn cancelReassessment btn-danger reassessmentButtonsAdmin"><span class="glyphicon glyphicon-remove"></span></button>\n<button class="btn editReassessment btn-info reassessmentButtonsAdmin"><span class="glyphicon glyphicon-pencil"></span></button>\n<button class="btn completeReassessment btn-success reassessmentButtonsAdmin "><span class="glyphicon glyphicon-ok"></span></button>\n</div>\n</div>\n'));
}));

Template.__checkName("defaultPage");
Template["defaultPage"] = new Template("Template.defaultPage", (function() {
  var view = this;
  return HTML.Raw("<h3>Please select an option above.</h3>");
}));

Template.__checkName("showNextRetakes");
Template["showNextRetakes"] = new Template("Template.showNextRetakes", (function() {
  var view = this;
  return [ HTML.DIV({
    "class": "row"
  }, "\n", HTML.DIV({
    "class": "col-md-4"
  }, "\n", HTML.SELECT({
    name: "date",
    id: "selectDate",
    "class": "form-control"
  }, "\n", HTML.Raw('<option value="" selected="selected"></option>'), "\n", Blaze.Each(function() {
    return Spacebars.call(view.lookup("reassessmentFoundDay"));
  }, function() {
    return [ "\n", HTML.OPTION({
      value: function() {
        return Spacebars.mustache(view.lookup("."));
      }
    }, Blaze.View("lookup:.", function() {
      return Spacebars.mustache(view.lookup("."));
    })), "\n\n" ];
  }), "\n")), "\n"), "\n", HTML.DIV({
    "class": "row"
  }, "\n", HTML.DIV({
    "class": "col-md-4"
  }, "\n  ", Blaze.Each(function() {
    return Spacebars.call(view.lookup("reassessmentsBeforeSchool"));
  }, function() {
    return [ "\n\n          ", Spacebars.include(view.lookupTemplate("reassessmentAdminTemplate")), "\n\n  " ];
  }), "\n"), "\n", HTML.DIV({
    "class": "col-md-4"
  }, "\n  ", Blaze.Each(function() {
    return Spacebars.call(view.lookup("reassessmentsDuringLunchClass"));
  }, function() {
    return [ "\n\n          ", Spacebars.include(view.lookupTemplate("reassessmentAdminTemplate")), "\n\n  " ];
  }), "\n"), "\n", HTML.DIV({
    "class": "col-md-4"
  }, "\n  ", Blaze.Each(function() {
    return Spacebars.call(view.lookup("reassessmentsAfterSchool"));
  }, function() {
    return [ "\n\n          ", Spacebars.include(view.lookupTemplate("reassessmentAdminTemplate")), "\n\n  " ];
  }), "\n"), "\n") ];
}));

Template.__checkName("myCredits");
Template["myCredits"] = new Template("Template.myCredits", (function() {
  var view = this;
  return [ Blaze.If(function() {
    return Spacebars.call(view.lookup("isAdmin"));
  }, function() {
    return [ "\n  ", Spacebars.include(view.lookupTemplate("allUserSelect")), "\n  ", HTML.DIV({
      "class": "row"
    }, "\n    ", HTML.DIV({
      "class": "col-md-6 col-md-offset-3"
    }, "\n\n\n        credits last:\n      ", HTML.INPUT({
      type: "number",
      value: function() {
        return Spacebars.mustache(view.lookup("expirationLength"));
      },
      id: "creditLifetime",
      style: "width:40px"
    }), " days\n       ", HTML.BUTTON({
      id: "assignBulkExpiration"
    }, "Batch Set Default Expiration"), "\n    "), "\n  "), "\n  " ];
  }), "\n", HTML.DIV({
    "class": "row"
  }, "\n  ", HTML.DIV({
    "class": "col-md-8 col-md-offset-2"
  }, "\n    My unused credits:\n    ", HTML.TABLE({
    "class": "borderedTable"
  }, "\n    ", HTML.TR("\n    ", HTML.TD("Course:"), "\n    ", Blaze.If(function() {
    return Spacebars.call(view.lookup("isAdmin"));
  }, function() {
    return HTML.TD("User");
  }), "\n    ", HTML.TD("Received on:"), "\n    ", HTML.TD("Expires on:"), "\n    "), "\n    ", Blaze.Each(function() {
    return Spacebars.call(view.lookup("myUnusedCredits"));
  }, function() {
    return [ "\n    ", HTML.TR("\n    ", HTML.TD(Blaze.View("lookup:course", function() {
      return Spacebars.mustache(view.lookup("course"));
    })), "\n    ", Blaze.If(function() {
      return Spacebars.call(view.lookup("isAdmin"));
    }, function() {
      return HTML.TD(Blaze.View("lookup:getName", function() {
        return Spacebars.mustache(view.lookup("getName"), view.lookup("user"));
      }));
    }), "\n    ", HTML.TD(Blaze.View("lookup:shortenDate", function() {
      return Spacebars.mustache(view.lookup("shortenDate"), view.lookup("createdOn"));
    })), "\n    ", Blaze.Unless(function() {
      return Spacebars.call(view.lookup("isTeacher"));
    }, function() {
      return [ "\n     ", HTML.TD({
        "class": function() {
          return Spacebars.mustache(view.lookup("hasExpired"));
        }
      }, Blaze.View("lookup:shortenDate", function() {
        return Spacebars.mustache(view.lookup("shortenDate"), view.lookup("expiresOn"));
      })), "\n     " ];
    }), "\n     ", Blaze.If(function() {
      return Spacebars.call(view.lookup("isAdmin"));
    }, function() {
      return [ "\n     ", HTML.INPUT({
        type: "date",
        value: function() {
          return Spacebars.mustache(view.lookup("getDate"), view.lookup("expiresOn"));
        },
        "class": "creditExpiresDate"
      }), "\n     ", HTML.BUTTON({
        "class": "btn-small expireCredit"
      }, HTML.SPAN({
        "class": "glyphicon glyphicon-fire text-danger"
      })), "\n     ", HTML.BUTTON({
        "class": "btn-small defaultExpiration"
      }, HTML.SPAN({
        "class": "glyphicon glyphicon-asterisk text-success"
      })), "\n     ", Blaze.If(function() {
        return Spacebars.call(view.lookup("hasExpired"));
      }, function() {
        return HTML.SPAN({
          "class": "text-danger glyphicon glyphicon-exclamation-sign"
        });
      }), "\n     " ];
    }), "\n  "), "\n    " ];
  }), "\n\n    "), "\n  "), "\n"), "\n", HTML.DIV({
    "class": "row"
  }, "\n\n  ", HTML.DIV({
    "class": "col-md-8 col-md-offset-2"
  }, "\n    My used credits:\n    ", HTML.TABLE({
    "class": "bordered-table"
  }, "\n    ", HTML.TR("\n    ", HTML.TD("Course:"), "\n    ", Blaze.If(function() {
    return Spacebars.call(view.lookup("isAdmin"));
  }, function() {
    return HTML.TD("User");
  }), "\n    ", HTML.TD("Created:"), "\n    ", HTML.TD("Status:"), "\n    "), "\n    ", Blaze.Each(function() {
    return Spacebars.call(view.lookup("myUsedCredits"));
  }, function() {
    return [ "\n    ", HTML.TR("\n    ", HTML.TD(Blaze.View("lookup:course", function() {
      return Spacebars.mustache(view.lookup("course"));
    })), "\n    ", Blaze.If(function() {
      return Spacebars.call(view.lookup("isAdmin"));
    }, function() {
      return HTML.TD(Blaze.View("lookup:getName", function() {
        return Spacebars.mustache(view.lookup("getName"), view.lookup("user"));
      }));
    }), "\n    ", HTML.TD(Blaze.View("lookup:shortenDate", function() {
      return Spacebars.mustache(view.lookup("shortenDate"), view.lookup("createdOn"));
    })), "\n\n     ", HTML.TD("\n       ", Blaze.Unless(function() {
      return Spacebars.call(view.lookup("isTeacher"));
    }, function() {
      return [ "\n       ", Blaze.If(function() {
        return Spacebars.call(view.lookup("expired"));
      }, function() {
        return [ "Expired ", Blaze.View("lookup:shortenDate", function() {
          return Spacebars.mustache(view.lookup("shortenDate"), view.lookup("expiresOn"));
        }) ];
      }), "\n       ", Blaze.If(function() {
        return Spacebars.call(view.lookup("used"));
      }, function() {
        return Blaze.View("lookup:reassessSummary", function() {
          return Spacebars.mustache(view.lookup("reassessSummary"));
        });
      }), "\n\n\n\n     " ];
    }), "\n     ", Blaze.If(function() {
      return Spacebars.call(view.lookup("isTeacher"));
    }, function() {
      return [ "\n\n     ", Blaze.If(function() {
        return Spacebars.call(view.lookup("expired"));
      }, function() {
        return [ "\n     Expired: ", Blaze.View("lookup:shortenDate", function() {
          return Spacebars.mustache(view.lookup("shortenDate"), view.lookup("expiresOn"));
        }), "\n     ", HTML.BUTTON({
          "class": "btn-small restoreCredit"
        }, HTML.SPAN({
          "class": "glyphicon glyphicon-flash"
        })) ];
      }), "\n     ", Blaze.If(function() {
        return Spacebars.call(view.lookup("used"));
      }, function() {
        return [ "\n     Used ", Blaze.View("lookup:reassessSummary", function() {
          return Spacebars.mustache(view.lookup("reassessSummary"));
        }), "\n     " ];
      }), "\n     " ];
    }), "\n     "), "\n    "), "\n    " ];
  }), "\n\n    "), "\n  "), "\n") ];
}));

}).call(this);
