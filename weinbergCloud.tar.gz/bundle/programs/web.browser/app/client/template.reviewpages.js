(function(){
Template.__checkName("reviewpages");
Template["reviewpages"] = new Template("Template.reviewpages", (function() {
  var view = this;
  return HTML.DIV({
    "class": "span6 offset2"
  }, "\nMy Standard: ", HTML.INPUT({
    type: "text",
    id: "reviewStandardText",
    placeholder: "Example: 7.2",
    value: function() {
      return Spacebars.mustache(view.lookup("myValue"));
    }
  }), HTML.Raw("  <p></p>  \nMy URL: "), HTML.INPUT({
    type: "text",
    id: "reviewURL",
    placeholder: "Paste the address of your blog post here.",
    value: function() {
      return Spacebars.mustache(view.lookup("myPage"));
    }
  }), HTML.Raw("<p></p>\nPlace this code somewhere in your blog post. Other students will need this code to vote for your page:"), HTML.H4({
    "class": "text-warning"
  }, Blaze.View("lookup:myCode", function() {
    return Spacebars.mustache(view.lookup("myCode"));
  })), HTML.Raw('\n<button id="submitReviewPage">Submit my URL</button>\n    <hr>\n    \n    '), Blaze.Each(function() {
    return Spacebars.call(view.lookup("reviewpage"));
  }, function() {
    return [ "\n    ", Blaze.If(function() {
      return Spacebars.call(view.lookup("shouldShow"));
    }, function() {
      return [ "\n    ", Spacebars.include(view.lookupTemplate("postItem")), "\n    " ];
    }), "\n    " ];
  }), "\n");
}));

Template.__checkName("postItem");
Template["postItem"] = new Template("Template.postItem", (function() {
  var view = this;
  return HTML.DIV({
    "class": "post"
  }, "\n      \n     ", HTML.A({
    href: "#",
    "class": "upvote btn"
  }, " ", Blaze.Unless(function() {
    return Spacebars.call(view.lookup("hasVoted"));
  }, function() {
    return "⬆";
  }), " ", Blaze.If(function() {
    return Spacebars.call(view.lookup("hasVoted"));
  }, function() {
    return HTML.I({
      "class": "icon-ok"
    });
  })), " \n\n", HTML.SPAN({
    "class": "badge badge-inverse"
  }, Blaze.View("lookup:votes", function() {
    return Spacebars.mustache(view.lookup("votes"));
  })), "    \n\n", HTML.A({
    href: function() {
      return Spacebars.mustache(view.lookup("url"));
    },
    target: "_blank"
  }, "Standard ", Blaze.View("lookup:standard", function() {
    return Spacebars.mustache(view.lookup("standard"));
  })), " -  submitted by ", Blaze.View("lookup:author", function() {
    return Spacebars.mustache(view.lookup("author"));
  }), " ", Blaze.If(function() {
    return Spacebars.call(view.lookup("weinbergApproved"));
  }, function() {
    return [ " ", HTML.I({
      "class": "icon-ok"
    }), "WB" ];
  }), "\n      ", Blaze.If(function() {
    return Spacebars.call(view.lookup("isWeinberg"));
  }, function() {
    return [ " ", HTML.SPAN({
      "class": "reviewCode"
    }, Blaze.View("lookup:_id", function() {
      return Spacebars.mustache(view.lookup("_id"));
    })) ];
  }), "\n      \n     \n       \n \n    \n  ");
}));

}).call(this);
