(function(){
Template.__checkName("addStandards");
Template["addStandards"] = new Template("Template.addStandards", (function() {
  var view = this;
  return [ HTML.Raw("<h3>Add standards here:</h3>\n"), HTML.FORM({
    "class": "form-horizontal"
  }, "\n", HTML.DIV({
    "class": "row"
  }, "\n  ", HTML.DIV({
    "class": "col-md-6"
  }, "\n\n", HTML.DIV({
    "class": "control-group"
  }, "\n", HTML.Raw('<label class="control-label">Course:</label>'), "\n", HTML.DIV({
    "class": "controls"
  }, "\n", HTML.SELECT({
    name: "addStandardCourse",
    "class": " form-control"
  }, "\n", HTML.Raw('<option value=""></option>'), "\n", Blaze.Each(function() {
    return Spacebars.call(view.lookup("courseNames"));
  }, function() {
    return [ "\n", HTML.OPTION({
      value: function() {
        return Spacebars.mustache(view.lookup("."));
      }
    }, Blaze.View("lookup:.", function() {
      return Spacebars.mustache(view.lookup("."));
    })), "\n" ];
  }), "\n"), "\n", HTML.Raw('<input id="addNewStandardName" placeholder="Or add a new course name here." class="form-control">'), "\n "), "\n "), "\n "), "\n\n "), "\n", HTML.DIV({
    "class": "control-group"
  }, "\n", HTML.Raw('<label class="control-label">Unit:</label>'), "\n", HTML.Raw('<div class="controls">\n<input id="addStandardUnit" name="addStandardUnit" class="addStandardsInput" type="number" min="0" max="12">\n </div>'), "\n", HTML.Raw("<p></p>"), "\n", HTML.Raw('<label class="control-label">Standard:</label>'), "\n", HTML.DIV({
    "class": "controls"
  }, "\n", HTML.Raw('<input id="addStandardStandard" name="addStandardStandard" class="addStandardsInput" type="number" min="0" max="12">'), Blaze.If(function() {
    return Spacebars.call(view.lookup("standardAlreadyExists"));
  }, function() {
    return [ "\n    ", HTML.SPAN({
      "class": "text-warning"
    }, "Standard Already Exists!"), "\n    " ];
  }), "\n "), "\n "), "\n\n", HTML.Raw('<div class="control-group">\n<label class="control-label">Title:</label>\n<div class="controls">\n<input name="addStandardTitle" class="addStandardsInput" type="text">\n </div>\n </div>'), "\n", HTML.DIV({
    "class": "control-group"
  }, "\n", HTML.Raw('<label class="control-label">Description:</label>'), "\n", HTML.DIV({
    "class": "controls"
  }, "\n", HTML.TEXTAREA({
    name: "addStandardDescription",
    "class": "addStandardsInput",
    rows: "4",
    cols: "80"
  }), "\n "), "\n "), "\n", HTML.Raw('<button class="btn btn-primary" id="addStandardsButton">Submit Standard</button>'), "\n") ];
}));

Template.__checkName("editStandards");
Template["editStandards"] = new Template("Template.editStandards", (function() {
  var view = this;
  return [ HTML.Raw("<h3>Edit Standards:</h3>\n"), HTML.FORM({
    "class": "form-horizontal"
  }, "\n", HTML.DIV({
    "class": "control-group"
  }, "\n", HTML.Raw('<label class="control-label">Course:</label>'), "\n", HTML.DIV({
    "class": "controls"
  }, "\n", HTML.SELECT({
    name: "editStandardCourse",
    "class": "editStandardsInput form-control",
    id: "editStandardCourse"
  }, "\n", HTML.OPTION({
    value: function() {
      return Spacebars.mustache(view.lookup("course"));
    }
  }, Blaze.View("lookup:course", function() {
    return Spacebars.mustache(view.lookup("course"));
  })), "\n"), "\n "), "\n "), "\n", HTML.DIV({
    "class": "control-group"
  }, "\n", HTML.Raw('<label class="control-label">Unit:</label>'), "\n", HTML.DIV({
    "class": "controls"
  }, "\n", HTML.INPUT({
    id: "editStandardUnit",
    "class": "editStandardsInput",
    type: "number",
    min: "0",
    max: "12",
    value: function() {
      return Spacebars.mustache(view.lookup("unit"));
    }
  }), "\n "), "\n", HTML.Raw("<p></p>"), "\n", HTML.Raw('<label class="control-label">Standard:</label>'), "\n", HTML.DIV({
    "class": "controls"
  }, "\n", HTML.INPUT({
    id: "editStandardStandard",
    "class": "editStandardsInput",
    type: "number",
    min: "0",
    max: "12",
    value: function() {
      return Spacebars.mustache(view.lookup("standard"));
    }
  }), "\n "), "\n "), "\n\n", HTML.DIV({
    "class": "control-group"
  }, "\n", HTML.Raw('<label class="control-label">Title:</label>'), "\n", HTML.DIV({
    "class": "controls"
  }, "\n", HTML.INPUT({
    id: "editStandardTitle",
    "class": "editStandardsInput",
    type: "text",
    value: function() {
      return Spacebars.mustache(view.lookup("title"));
    }
  }), "\n "), "\n "), "\n", HTML.DIV({
    "class": "control-group"
  }, "\n", HTML.Raw('<label class="control-label">Description:</label>'), "\n", HTML.DIV({
    "class": "controls"
  }, "\n", HTML.TEXTAREA({
    id: "editStandardDescription",
    "class": "editStandardsInput",
    rows: "4",
    cols: "80",
    value: function() {
      return Spacebars.mustache(view.lookup("description"));
    }
  }), "\n "), "\n "), "\n", HTML.Raw('<button class="btn btn-primary" id="editStandardsButton">Update</button>'), "\n") ];
}));

Template.__checkName("viewStandards");
Template["viewStandards"] = new Template("Template.viewStandards", (function() {
  var view = this;
  return [ HTML.DIV({
    "class": "row "
  }, "\n", HTML.DIV({
    "class": "col-md-6"
  }, "\n", HTML.SELECT({
    id: "viewStandardsSelectCourse",
    "class": "form-control"
  }, "\n", HTML.Raw('<option value=""></option>'), "\n", Blaze.Each(function() {
    return Spacebars.call(view.lookup("courseNames"));
  }, function() {
    return [ "\n", HTML.OPTION({
      value: function() {
        return Spacebars.mustache(view.lookup("."));
      }
    }, Blaze.View("lookup:.", function() {
      return Spacebars.mustache(view.lookup("."));
    })), "\n" ];
  }), "\n"), "\n"), "\n"), "\n", HTML.DIV({
    "class": "row"
  }, "\n  ", HTML.DIV({
    "class": "col-md-8"
  }, "\n", HTML.TABLE({
    id: "standardsTable",
    "class": "table"
  }, "\n", HTML.TR("\n", HTML.TD("Active?"), HTML.TD("Standard"), HTML.TD("Title"), HTML.TD("Delete?"), "\n\n\n"), "\n", Blaze.Each(function() {
    return Spacebars.call(view.lookup("standards"));
  }, function() {
    return [ "\n", HTML.TR("\n  ", Blaze.If(function() {
      return Spacebars.call(view.lookup("isAdmin"));
    }, function() {
      return [ "\n", HTML.TD("\n\n  ", HTML.INPUT(HTML.Attrs({
        type: "checkbox",
        "class": "standardActive"
      }, function() {
        return Spacebars.attrMustache(view.lookup("active"));
      }))), "\n" ];
    }), "\n", HTML.TD(Blaze.View("lookup:unit", function() {
      return Spacebars.mustache(view.lookup("unit"));
    }), ".", Blaze.View("lookup:standard", function() {
      return Spacebars.mustache(view.lookup("standard"));
    }), "\n    ", Blaze.If(function() {
      return Spacebars.call(view.lookup("isAdmin"));
    }, function() {
      return [ "\n    ", HTML.A({
        href: function() {
          return [ "/standards/edit/", Spacebars.mustache(view.lookup("_id")) ];
        }
      }, "Edit") ];
    }), "\n\n\n  "), HTML.TD(HTML.A({
      href: function() {
        return [ "/standards/view/", Spacebars.mustache(view.lookup("_id")) ];
      }
    }, Blaze.View("lookup:title", function() {
      return Spacebars.mustache(view.lookup("title"));
    }))), "\n  ", Blaze.If(function() {
      return Spacebars.call(view.lookup("isAdmin"));
    }, function() {
      return [ "\n  ", HTML.TD(HTML.BUTTON({
        "class": "btn btn-small btn-danger deleteStandard"
      }, "Delete")), "\n  " ];
    }), "\n\n"), "\n" ];
  }), "\n"), "\n"), "\n") ];
}));

Template.__checkName("viewStandard");
Template["viewStandard"] = new Template("Template.viewStandard", (function() {
  var view = this;
  return [ HTML.Raw('<a href="/standards/view/"> &lt;&lt;&lt;Back</a>\n\n\n'), HTML.DIV({
    id: "viewStandardInformation"
  }, "\n", HTML.H3(Blaze.View("lookup:course", function() {
    return Spacebars.mustache(view.lookup("course"));
  }), " Standard ", Blaze.View("lookup:unit", function() {
    return Spacebars.mustache(view.lookup("unit"));
  }), ".", Blaze.View("lookup:standard", function() {
    return Spacebars.mustache(view.lookup("standard"));
  }), ": ", Blaze.View("lookup:title", function() {
    return Spacebars.mustache(view.lookup("title"));
  })), "\n\n", HTML.DIV({
    id: "viewStandardDescription"
  }, "\n\n    ", Blaze.View("lookup:description", function() {
    return Spacebars.mustache(view.lookup("description"));
  }), "\n\n"), "\n"), "\n\n\n    ", Blaze.If(function() {
    return Spacebars.call(view.lookup("isAdmin"));
  }, function() {
    return [ "\n", Spacebars.include(view.lookupTemplate("submitStandardLink")), "\n    " ];
  }), HTML.Raw("\n    <h3>Links for this standard:</h3>\n    "), Blaze.Each(function() {
    return Spacebars.call(view.lookup("links"));
  }, function() {
    return [ "\n    ", Spacebars.include(view.lookupTemplate("linkTemplate")), "\n    " ];
  }) ];
}));

Template.__checkName("linkTemplate");
Template["linkTemplate"] = new Template("Template.linkTemplate", (function() {
  var view = this;
  return HTML.DIV({
    "class": "standardsLinkItem"
  }, "\n", HTML.H4(HTML.A({
    href: function() {
      return Spacebars.mustache(view.lookup("url"));
    },
    target: "_blank"
  }, Blaze.View("lookup:title", function() {
    return Spacebars.mustache(view.lookup("title"));
  }))), "\n");
}));

Template.__checkName("submitStandardLink");
Template["submitStandardLink"] = new Template("Template.submitStandardLink", (function() {
  var view = this;
  return [ HTML.Raw('<div class="form-group">\n      <label class="control-label" for="url">Resource URL</label>\n      <div class="controls">\n          <input name="url" id="submitLinkURL" type="text" value="" placeholder="Your URL" class="form-control submitLink">\n      </div>\n    </div>\n    <div class="form-group">\n      <label class="control-label" for="title">Resource Title</label>\n      <div class="controls">\n          <input name="title" id="submitLinkTitle" type="text" value="" placeholder="Name your post" class="form-control submitLink">\n      </div>\n    </div>\n    <input type="submit" value="Submit" class="btn btn-primary" id="standardLinkButton">\n    '), HTML.DIV({
    id: "submitLinkHiddenInformation"
  }, "\n    ", HTML.SPAN({
    id: "submitLinkCourse"
  }, Blaze.View("lookup:course", function() {
    return Spacebars.mustache(view.lookup("course"));
  })), "\n    ", HTML.SPAN({
    id: "submitLinkUnit"
  }, Blaze.View("lookup:unit", function() {
    return Spacebars.mustache(view.lookup("unit"));
  })), "\n    ", HTML.SPAN({
    id: "submitLinkStandard"
  }, Blaze.View("lookup:standard", function() {
    return Spacebars.mustache(view.lookup("standard"));
  })), "\n    ") ];
}));

}).call(this);
