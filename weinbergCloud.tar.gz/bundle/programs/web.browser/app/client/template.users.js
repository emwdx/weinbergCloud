(function(){
Template.__checkName("creditBadge");
Template["creditBadge"] = new Template("Template.creditBadge", (function() {
  var view = this;
  return HTML.SPAN({
    "class": "badge badge-inverse"
  }, Blaze.View("lookup:numberOfCredits", function() {
    return Spacebars.mustache(view.lookup("numberOfCredits"));
  }));
}));

Template.__checkName("myCreditsBadge");
Template["myCreditsBadge"] = new Template("Template.myCreditsBadge", (function() {
  var view = this;
  return HTML.SPAN({
    "class": "badge badge-inverse"
  }, Blaze.View("lookup:numberOfCredits", function() {
    return Spacebars.mustache(view.lookup("numberOfCredits"));
  }));
}));

Template.__checkName("userProfile");
Template["userProfile"] = new Template("Template.userProfile", (function() {
  var view = this;
  return HTML.FORM({
    "class": "form-inline ",
    id: function() {
      return [ "profile_", Spacebars.mustache(view.lookup("_id")) ];
    }
  }, "\n", HTML.DIV({
    "class": "row"
  }, "\n", HTML.DIV({
    "class": "col-md-9 text-center"
  }, "\n\n\n\n", HTML.DIV({
    "class": "form-group"
  }, "\n  ", HTML.Raw('<button class="btn btn-primary updateProfile">Update</button>'), "\n", HTML.INPUT({
    type: "text",
    id: "profileUserName",
    value: function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("."), "profile", "realName"));
    },
    placeholder: "Student Name",
    "class": "form-control"
  }), "\n"), "\n", HTML.DIV({
    "class": "form-group"
  }, "\n", HTML.SELECT({
    id: "userSelectTeacher",
    "class": "form-control"
  }, "\n\n  ", Blaze.Each(function() {
    return Spacebars.call(view.lookup("teacherUser"));
  }, function() {
    return [ "\n  ", HTML.OPTION({
      value: function() {
        return Spacebars.mustache(view.lookup("."));
      },
      selected: function() {
        return Spacebars.mustache(view.lookup("isEqual"), view.lookup("."), Spacebars.dot(view.lookup(".."), "profile", "teacher"));
      }
    }, Blaze.View("lookup:.", function() {
      return Spacebars.mustache(view.lookup("."));
    })), "\n  " ];
  }), "\n"), "\n\n"), "\n"), "\n"), "\n", HTML.DIV({
    "class": "row"
  }, "\n  ", HTML.DIV({
    "class": "col-md-12 "
  }, "\n\n", HTML.Raw('<label class="control-label">Courses:</label>'), "\n\n", Blaze.Each(function() {
    return Spacebars.call(view.lookup("courses"));
  }, function() {
    return [ "\n\n\n", HTML.LABEL({
      "class": "checkbox-inline"
    }, HTML.INPUT(HTML.Attrs({
      type: "checkbox",
      "class": "userHasCourse"
    }, function() {
      return Spacebars.attrMustache(view.lookup("hasCourse"), view.lookup("."));
    })), HTML.SPAN({
      "class": "courseName"
    }, Blaze.View("lookup:.", function() {
      return Spacebars.mustache(view.lookup("."));
    }))), "\n\n\n" ];
  }), "\n\n"), "\n"), "\n\n");
}));

Template.__checkName("allUsers");
Template["allUsers"] = new Template("Template.allUsers", (function() {
  var view = this;
  return [ Spacebars.include(view.lookupTemplate("allUserSelect")), "\n", HTML.DIV({
    "class": "row"
  }, "\n", HTML.DIV({
    "class": "col-md-12"
  }, "\n  ", HTML.DIV({
    "class": "list-group",
    id: "accordion",
    role: "tablist",
    "aria-multiselectable": "true"
  }, "\n    ", Blaze.Each(function() {
    return Spacebars.call(view.lookup("userProfiles"));
  }, function() {
    return [ "\n\n      ", HTML.DIV({
      "class": "panel-heading",
      role: "tab",
      id: function() {
        return [ "heading_", Spacebars.mustache(view.lookup("_id")) ];
      }
    }, "\n        ", HTML.H4({
      "class": "panel-title"
    }, "\n          ", HTML.A({
      role: "button",
      "data-toggle": "collapse",
      "data-parent": "#accordion",
      href: function() {
        return [ "#collapse_", Spacebars.mustache(view.lookup("_id")) ];
      },
      "aria-expanded": "false",
      "aria-controls": function() {
        return [ "collapse_", Spacebars.mustache(view.lookup("_id")) ];
      }
    }, "\n            ", Spacebars.include(view.lookupTemplate("userInfoTemplate")), "\n          "), "\n        "), "\n      "), "\n      ", HTML.DIV({
      id: function() {
        return [ "collapse_", Spacebars.mustache(view.lookup("_id")) ];
      },
      "class": "panel-collapse collapse",
      role: "tabpanel",
      "aria-labelledby": function() {
        return [ "heading_", Spacebars.mustache(view.lookup("_id")) ];
      }
    }, "\n        ", HTML.DIV({
      "class": "list-group"
    }, "\n          ", Spacebars.include(view.lookupTemplate("userProfile")), "\n        "), "\n      "), "\n\n\n  " ];
  }), "\n"), "\n\n    "), "\n  ") ];
}));

Template.__checkName("userInfoTemplate");
Template["userInfoTemplate"] = new Template("Template.userInfoTemplate", (function() {
  var view = this;
  return HTML.DIV({
    "class": "row userInfoItem"
  }, "\n\n", HTML.DIV({
    "class": "col-md-4"
  }, "\nCredits:", Spacebars.include(view.lookupTemplate("creditBadge")), "\n"), "\n", HTML.DIV({
    "class": "col-md-4"
  }, "\n", Blaze.View("lookup:emails.0.address", function() {
    return Spacebars.mustache(Spacebars.dot(view.lookup("emails"), "0", "address"));
  }), "\n", HTML.Raw("<br>"), "\nName: ", Blaze.View("lookup:profile.realName", function() {
    return Spacebars.mustache(Spacebars.dot(view.lookup("profile"), "realName"));
  }), "\n"), HTML.Raw('\n\n<div class="col-md-4 ">\n<button class="addCredit  btn btn-success btn-med"><span class="glyphicon glyphicon-plus"></span> Credit</button><button class="removeCredit btn btn-danger btn-med"><span class="glyphicon glyphicon-minus"></span> Credit</button>\n</div>\n'));
}));

Template.__checkName("adminTemplate");
Template["adminTemplate"] = new Template("Template.adminTemplate", (function() {
  var view = this;
  return Blaze.If(function() {
    return Spacebars.call(view.lookup("isAdmin"));
  }, function() {
    return [ "\n        ", Spacebars.include(view.lookupTemplate("accountsAdmin")), "\n    " ];
  }, function() {
    return "\n        Must be admin to see this...\n    ";
  });
}));

Template.__checkName("allUserSelect");
Template["allUserSelect"] = new Template("Template.allUserSelect", (function() {
  var view = this;
  return HTML.DIV({
    "class": "row "
  }, "\n\n  ", HTML.DIV({
    "class": "col-md-4"
  }, "\n\n  ", HTML.SELECT({
    id: "userCourseSelect",
    "class": "reassessSelect form-control"
  }, "\n    ", HTML.Raw('<option value="0" selected="selected"></option>'), "\n    ", Blaze.Each(function() {
    return Spacebars.call(view.lookup("reassessCourse"));
  }, function() {
    return [ "\n    ", HTML.OPTION({
      value: function() {
        return Spacebars.mustache(view.lookup("."));
      }
    }, Blaze.View("lookup:.", function() {
      return Spacebars.mustache(view.lookup("."));
    })), "\n    " ];
  }), "\n\n\n  "), "\n  "), "\n  ", HTML.DIV({
    "class": "col-md-4"
  }, "\n  ", HTML.SELECT({
    id: "userTeacherSelect",
    "class": "reassessSelect form-control"
  }, "\n    ", HTML.Raw('<option value="0" selected="selected"></option>'), "\n    ", Blaze.Each(function() {
    return Spacebars.call(view.lookup("teacherUser"));
  }, function() {
    return [ "\n    ", HTML.OPTION({
      value: function() {
        return Spacebars.mustache(view.lookup("."));
      }
    }, Blaze.View("lookup:.", function() {
      return Spacebars.mustache(view.lookup("."));
    })), "\n    " ];
  }), "\n\n\n  "), "\n  "), "\n  ");
}));

}).call(this);
