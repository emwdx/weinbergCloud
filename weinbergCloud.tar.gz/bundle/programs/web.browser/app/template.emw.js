(function(){
Template.__checkName("mainContent");
Template["mainContent"] = new Template("Template.mainContent", (function() {
  var view = this;
  return HTML.DIV({
    "class": "container"
  }, "\n\n\n\n\n", HTML.DIV({
    "class": "row"
  }, "\n  ", HTML.H2({
    "class": "text-center"
  }, "\n   ", Spacebars.include(view.lookupTemplate("loggingIn")), "\n  ", Blaze.Unless(function() {
    return Spacebars.call(view.lookup("currentUser"));
  }, function() {
    return [ "\n  ", HTML.DIV({
      "class": "text-center"
    }, "\n  ", Spacebars.include(view.lookupTemplate("atForm")), "\n  "), "\n\n  " ];
  }), "\n  "), "\n  "), "\n  ", Blaze.If(function() {
    return Spacebars.call(view.lookup("currentUser"));
  }, function() {
    return [ "\n  ", HTML.DIV({
      "class": "text-center"
    }, "\n\n  "), "\n  ", Spacebars.include(view.lookupTemplate("studentOptionsBar")), "\n    ", Spacebars.include(view.lookupTemplate("announcements")), "\n\n  ", Blaze.If(function() {
      return Spacebars.call(view.lookup("appReady"));
    }, function() {
      return [ "\n  ", Spacebars.include(view.lookupTemplate("yield")), "\n\n  " ];
    }, function() {
      return [ "\n  ", Spacebars.include(view.lookupTemplate("loading")), "\n\n  " ];
    }), "\n\n\n  " ];
  }), "\n");
}));

Template.__checkName("studentOptionsBar");
Template["studentOptionsBar"] = new Template("Template.studentOptionsBar", (function() {
  var view = this;
  return HTML.NAV({
    "class": "navbar navbar-default"
  }, "\n  ", HTML.DIV({
    "class": "container-fluid"
  }, "\n    ", HTML.Raw('<div class="navbar-header">\n\n    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">\n              <span class="sr-only">Toggle navigation</span>\n              <span class="icon-bar"></span>\n              <span class="icon-bar"></span>\n              <span class="icon-bar"></span>\n    </button>\n\n    <div class="navbar-brand">\n        <span class="nav"> WeinbergCloud: </span>\n    </div>\n    </div>'), "\n     ", HTML.DIV({
    id: "navbar",
    "class": "navbar-collapse collapse"
  }, "\n\n      ", HTML.UL({
    "class": "nav navbar-nav"
  }, "\n      ", HTML.LI(HTML.A({
    href: "#"
  }, Spacebars.include(view.lookupTemplate("loginButtons")))), "\n\n      ", HTML.LI({
    "class": "dropdown"
  }, "\n      ", HTML.Raw('<a href="#" class="dropdown-toggle" data-toggle="dropdown"><b class="caret"></b>&nbsp;Reassessments</a>'), "\n      ", HTML.UL({
    "class": "dropdown-menu"
  }, "\n       ", HTML.Raw('<li id="signUp"><a href="/reassess/add/">Reassessment Sign-up</a></li>'), "\n      ", HTML.Raw('<li id="myReassessments"><a href="/myReassessments/">My Reassessments</a> </li>'), "\n      ", HTML.Raw('<li id="myCredits"><a href="/credits/">My Credits</a> </li>'), "\n      ", HTML.Raw('<li id="myQuizzes"><a href="/myQuizzes/">My Quizzes</a> </li>'), "\n      ", HTML.Raw('<li role="separator" class="divider"></li>'), "\n        ", Blaze.If(function() {
    return Spacebars.call(view.lookup("isTeacher"));
  }, function() {
    return [ "\n        ", HTML.LI({
      id: "allReassessments"
    }, HTML.A({
      href: "/retakes/"
    }, "All Reassessments")), "\n        ", HTML.LI({
      id: "allUsers"
    }, HTML.A({
      href: "/allUsers/"
    }, "All Users")), "\n        ", HTML.LI({
      id: "allQuizzes"
    }, HTML.A({
      href: "/allQuizzes/"
    }, "All Quizzes")), "\n        ", HTML.Comment('li id = "games"><a href = "/games/">Games</a></li'), "\n        ", HTML.LI({
      role: "separator",
      "class": "divider"
    }), "\n        ", Blaze.If(function() {
      return Spacebars.call(view.lookup("isAdmin"));
    }, function() {
      return [ "\n        ", HTML.LI({
        id: "usermanagement"
      }, HTML.A({
        href: "/admin/"
      }, "Manage Users")), "\n        ", HTML.LI({
        id: "desmos"
      }, HTML.A({
        href: "/desmos/"
      }, "Desmos")), "\n        ", HTML.LI({
        id: "mathquill"
      }, HTML.A({
        href: "/math-quill-demo/"
      }, "MathQuill")), "\n        " ];
    }), "\n        " ];
  }), "\n        "), "\n    "), "\n\n    ", HTML.LI({
    "class": "dropdown"
  }, "\n    ", HTML.Raw('<a href="#" class="dropdown-toggle" data-toggle="dropdown"><b class="caret"></b>&nbsp;Standards</a>'), "\n     ", HTML.UL({
    "class": "dropdown-menu"
  }, "\n         ", Blaze.If(function() {
    return Spacebars.call(view.lookup("isTeacher"));
  }, function() {
    return [ "\n     ", HTML.LI({
      id: "addStandards"
    }, HTML.A({
      href: "/standards/add/"
    }, "Add")), "\n         " ];
  }), "\n     ", HTML.Raw('<li id="viewStandards"><a href="/standards/view/">View </a></li>'), "\n      ", Blaze.If(function() {
    return Spacebars.call(view.lookup("isTeacher"));
  }, function() {
    return [ "\n     ", HTML.LI({
      id: "questionBuilder"
    }, HTML.A({
      href: "/questions/edit/add"
    }, "Create New")), "\n     ", HTML.LI({
      id: "listQuestions"
    }, HTML.A({
      href: "/list-questions/"
    }, "See All Questions")), "\n      " ];
  }), "\n     "), "\n    "), "\n    "), "\n\n    ", HTML.UL({
    "class": "nav pull-right"
  }, "\n        ", HTML.LI(HTML.A(HTML.SPAN({
    style: function() {
      return Spacebars.mustache(view.lookup("connectionClass"));
    }
  }, Blaze.View("lookup:connectionStatus", function() {
    return Spacebars.mustache(view.lookup("connectionStatus"));
  }))), " "), "\n\n    "), "\n    "), "\n    "), "\n\n");
}));

Template.__checkName("loggingIn");
Template["loggingIn"] = new Template("Template.loggingIn", (function() {
  var view = this;
  return Blaze.If(function() {
    return Spacebars.call(view.lookup("isLoggingIn"));
  }, function() {
    return [ "\n", HTML.P({
      "class": "text-center text-info"
    }, "Logging in to WeinbergCloud..."), "\n    ", Spacebars.include(view.lookupTemplate("spinner")), "\n    " ];
  });
}));

Template.__checkName("announcements");
Template["announcements"] = new Template("Template.announcements", (function() {
  var view = this;
  return HTML.DIV({
    "class": "span11 offset1"
  }, "\n    ", Blaze.View("lookup:currentAnnouncement", function() {
    return Spacebars.makeRaw(Spacebars.mustache(view.lookup("currentAnnouncement")));
  }), "\n\n");
}));

Template.__checkName("setAnnouncement");
Template["setAnnouncement"] = new Template("Template.setAnnouncement", (function() {
  var view = this;
  return Blaze.If(function() {
    return Spacebars.call(view.lookup("isAdmin"));
  }, function() {
    return [ "\n", HTML.DIV({
      "class": "span11 offset1"
    }, "\n", HTML.INPUT({
      type: "text",
      id: "announcementText"
    }), "\n", HTML.BUTTON({
      "class": "btn btn-primary",
      id: "submitAnnouncementButton"
    }, "Set announcement"), "\n\n"), "\n    " ];
  });
}));

}).call(this);
