(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var Accounts = Package['accounts-base'].Accounts;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['accounts-ui'] = {};

})();
