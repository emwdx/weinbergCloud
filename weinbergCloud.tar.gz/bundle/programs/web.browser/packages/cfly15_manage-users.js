//////////////////////////////////////////////////////////////////////////
//                                                                      //
// This is a generated file. You can view the original                  //
// source in your browser if your browser supports source maps.         //
// Source maps are supported by all recent versions of Chrome, Safari,  //
// and Firefox, and by Internet Explorer 11.                            //
//                                                                      //
//////////////////////////////////////////////////////////////////////////


(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var Roles = Package['alanning:roles'].Roles;
var WebApp = Package.webapp.WebApp;
var Log = Package.logging.Log;
var Tracker = Package.deps.Tracker;
var Deps = Package.deps.Deps;
var Session = Package.session.Session;
var DDP = Package['ddp-client'].DDP;
var Mongo = Package.mongo.Mongo;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var Template = Package.templating.Template;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;
var $ = Package.jquery.$;
var jQuery = Package.jquery.jQuery;
var Random = Package.random.Random;
var EJSON = Package.ejson.EJSON;
var LaunchScreen = Package['launch-screen'].LaunchScreen;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var filteredUserQuery, users, ManageUsers;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/cfly15_manage-users/packages/cfly15_manage-users.js                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
(function () {                                                                                                         // 1
                                                                                                                       // 2
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/cfly15:manage-users/libs/user_query.js                                                                  //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
filteredUserQuery = function(userId, filter) {                                                                      // 1
	// if not an admin user don't show any other user                                                                  // 2
	if (!Roles.userIsInRole(userId, ['admin']))                                                                        // 3
		return Meteor.users.find(userId);                                                                                 // 4
                                                                                                                    // 5
	// TODO: configurable limit and paginiation                                                                        // 6
	var queryLimit = 25;                                                                                               // 7
                                                                                                                    // 8
	if(!!filter) {                                                                                                     // 9
		// TODO: passing to regex directly could be dangerous                                                             // 10
		users = Meteor.users.find({                                                                                       // 11
			$or: [                                                                                                           // 12
				{'profile.name': {$regex: filter, $options: 'i'}},                                                              // 13
				{'emails.address': {$regex: filter, $options: 'i'}}                                                             // 14
			]                                                                                                                // 15
		}, {sort: {emails: 1}, limit: queryLimit});                                                                       // 16
	} else {                                                                                                           // 17
		users = Meteor.users.find({}, {sort: {emails: 1}, limit: queryLimit});                                            // 18
	}                                                                                                                  // 19
	return users;                                                                                                      // 20
};                                                                                                                  // 21
                                                                                                                    // 22
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       // 32
}).call(this);                                                                                                         // 33
                                                                                                                       // 34
                                                                                                                       // 35
                                                                                                                       // 36
                                                                                                                       // 37
                                                                                                                       // 38
                                                                                                                       // 39
(function () {                                                                                                         // 40
                                                                                                                       // 41
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/cfly15:manage-users/client/startup.js                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
Meteor.startup(function() {                                                                                         // 1
	Meteor.subscribe('roles');                                                                                         // 2
	Deps.autorun(function(e) {                                                                                         // 3
		Meteor.subscribe('filteredUsers', Session.get('userFilter'));                                                     // 4
	});                                                                                                                // 5
});                                                                                                                 // 6
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       // 55
}).call(this);                                                                                                         // 56
                                                                                                                       // 57
                                                                                                                       // 58
                                                                                                                       // 59
                                                                                                                       // 60
                                                                                                                       // 61
                                                                                                                       // 62
(function () {                                                                                                         // 63
                                                                                                                       // 64
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/cfly15:manage-users/client/template.accounts_admin.js                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
                                                                                                                    // 1
Template.__checkName("accountsAdmin");                                                                              // 2
Template["accountsAdmin"] = new Template("Template.accountsAdmin", (function() {                                    // 3
  var view = this;                                                                                                  // 4
  return [ HTML.DIV({                                                                                               // 5
    "class": "row accounts-search"                                                                                  // 6
  }, "\n        ", HTML.DIV({                                                                                       // 7
    "class": "col-sm-offset-4 col-sm-8"                                                                             // 8
  }, "\n            ", HTML.DIV({                                                                                   // 9
    "class": "input-group"                                                                                          // 10
  }, "\n                ", HTML.INPUT({                                                                             // 11
    type: "text",                                                                                                   // 12
    "class": "form-control search-input-filter",                                                                    // 13
    value: function() {                                                                                             // 14
      return Spacebars.mustache(view.lookup("searchFilter"));                                                       // 15
    }                                                                                                               // 16
  }), "\n                ", HTML.Raw('<span class="input-group-btn">\n                    <button class="btn btn-default" type="button"><span><i class="fa fa-search"></i></span></button>\n                    <button class="btn btn-default" type="button" data-toggle="modal" href="#updateroles">Manage Roles</button>\n                    <button class="btn btn-primary" type="button" data-action="addUser" data-toggle="modal" href="#addUser"><i class="fa fa-plus"></i> Add User</button>\n                </span>'), "\n            "), "\n        "), "\n    "), "\n    ", HTML.TABLE({
    "class": "table table-striped"                                                                                  // 18
  }, "\n        ", HTML.THEAD("\n            ", HTML.TR("\n                ", HTML.TH(), "\n                ", HTML.TH("Name"), "\n                ", HTML.TH("Email"), "\n                ", HTML.TH("UserId"), "\n                ", HTML.TH("Roles"), "\n            "), "\n        "), "\n        ", HTML.TBODY("\n            ", Blaze.Each(function() {
    return Spacebars.call(view.lookup("users"));                                                                    // 20
  }, function() {                                                                                                   // 21
    return [ "\n                ", HTML.TR({                                                                        // 22
      "class": function() {                                                                                         // 23
        return Blaze.If(function() {                                                                                // 24
          return Spacebars.dataMustache(view.lookup("myself"), view.lookup("_id"));                                 // 25
        }, function() {                                                                                             // 26
          return "info";                                                                                            // 27
        });                                                                                                         // 28
      }                                                                                                             // 29
    }, "\n                    ", HTML.TD({                                                                          // 30
      "class": "userActionIcons"                                                                                    // 31
    }, "\n                      ", Blaze.Unless(function() {                                                        // 32
      return Spacebars.dataMustache(view.lookup("myself"), view.lookup("_id"));                                     // 33
    }, function() {                                                                                                 // 34
      return [ "\n                            ", HTML.SPAN({                                                        // 35
        "data-toggle": "modal",                                                                                     // 36
        "data-action": "delete",                                                                                    // 37
        href: "#deleteaccount",                                                                                     // 38
        "class": "clickable"                                                                                        // 39
      }, HTML.I({                                                                                                   // 40
        "class": "fa fa-trash"                                                                                      // 41
      })), "\n                            ", HTML.SPAN({                                                            // 42
        "data-toggle": "modal",                                                                                     // 43
        "data-action": "update",                                                                                    // 44
        href: "#updateaccount",                                                                                     // 45
        "class": "clickable"                                                                                        // 46
      }, HTML.I({                                                                                                   // 47
        "class": "fa fa-pencil"                                                                                     // 48
      })), "\n                            ", HTML.Comment(' <span data-toggle="modal" data-action="info" href="#infoaccount" class="clickable"><i class="fa fa-info"></i></span> '), "\n                            ", Blaze.If(function() {
        return Spacebars.dataMustache(view.lookup("isInRole"), "superAdmin");                                       // 50
      }, function() {                                                                                               // 51
        return HTML.SPAN({                                                                                          // 52
          "data-action": "impersonate",                                                                             // 53
          "class": "clickable"                                                                                      // 54
        }, HTML.I({                                                                                                 // 55
          "class": "fa fa-binoculars"                                                                               // 56
        }));                                                                                                        // 57
      }), "\n                      " ];                                                                             // 58
    }), "\n                    "), "\n                    ", HTML.TD("\n                        ", Blaze.If(function() {
      return Spacebars.call(Spacebars.dot(view.lookup("profile"), "name"));                                         // 60
    }, function() {                                                                                                 // 61
      return [ "\n                            ", Blaze.View(function() {                                            // 62
        return Spacebars.mustache(Spacebars.dot(view.lookup("profile"), "name"));                                   // 63
      }), "\n                        " ];                                                                           // 64
    }, function() {                                                                                                 // 65
      return [ "\n                            ", Blaze.View(function() {                                            // 66
        return Spacebars.mustache(view.lookup("email"));                                                            // 67
      }), "\n                        " ];                                                                           // 68
    }), "\n                    "), "\n                    ", HTML.TD(Blaze.View(function() {                        // 69
      return Spacebars.mustache(view.lookup("email"));                                                              // 70
    })), "\n                    ", HTML.TD(Blaze.View(function() {                                                  // 71
      return Spacebars.mustache(view.lookup("_id"));                                                                // 72
    })), "\n                    ", HTML.TD(Blaze.View(function() {                                                  // 73
      return Spacebars.mustache(view.lookup("roles"));                                                              // 74
    })), "\n                "), "\n            " ];                                                                 // 75
  }), "\n        "), "\n    "), "\n    ", Spacebars.include(view.lookupTemplate("updateRolesModal")), "\n    ", Spacebars.include(view.lookupTemplate("deleteAccountModal")), "\n    ", Spacebars.include(view.lookupTemplate("infoAccountModal")), "\n    ", Spacebars.include(view.lookupTemplate("updateAccountModal")), "\n    ", Spacebars.include(view.lookupTemplate("addUserModal")) ];
}));                                                                                                                // 77
                                                                                                                    // 78
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       // 150
}).call(this);                                                                                                         // 151
                                                                                                                       // 152
                                                                                                                       // 153
                                                                                                                       // 154
                                                                                                                       // 155
                                                                                                                       // 156
                                                                                                                       // 157
(function () {                                                                                                         // 158
                                                                                                                       // 159
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/cfly15:manage-users/client/accounts_admin.js                                                            //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
Template.accountsAdmin.helpers({                                                                                    // 1
	users: function() {                                                                                                // 2
		return filteredUserQuery(Meteor.userId(), Session.get("userFilter"));                                             // 3
	},                                                                                                                 // 4
                                                                                                                    // 5
	email: function () {                                                                                               // 6
		if (this.emails && this.emails.length)                                                                            // 7
			return this.emails[0].address;                                                                                   // 8
                                                                                                                    // 9
		if (this.services) {                                                                                              // 10
			//Iterate through services                                                                                       // 11
			for (var serviceName in this.services) {                                                                         // 12
				var serviceObject = this.services[serviceName];                                                                 // 13
				//If an 'id' isset then assume valid service                                                                    // 14
				if (serviceObject.id) {                                                                                         // 15
					if (serviceObject.email) {                                                                                     // 16
						return serviceObject.email;                                                                                   // 17
					}                                                                                                              // 18
				}                                                                                                               // 19
			}                                                                                                                // 20
		}                                                                                                                 // 21
		return "";                                                                                                        // 22
	},                                                                                                                 // 23
                                                                                                                    // 24
	searchFilter: function() {                                                                                         // 25
		return Session.get("userFilter");                                                                                 // 26
	},                                                                                                                 // 27
                                                                                                                    // 28
	myself: function(userId) {                                                                                         // 29
		return Meteor.userId() === userId;                                                                                // 30
	}                                                                                                                  // 31
});                                                                                                                 // 32
                                                                                                                    // 33
// search no more than 2 times per second                                                                           // 34
var setUserFilter = _.throttle(function(template) {                                                                 // 35
	var search = template.find(".search-input-filter").value;                                                          // 36
	Session.set("userFilter", search);                                                                                 // 37
}, 500);                                                                                                            // 38
                                                                                                                    // 39
Template.accountsAdmin.events({                                                                                     // 40
	'keyup .search-input-filter': function(event, template) {                                                          // 41
        setUserFilter(template);                                                                                    // 42
        return false;                                                                                               // 43
    },                                                                                                              // 44
                                                                                                                    // 45
    'click [data-action="delete"]': function(event, template) {                                                     // 46
		Session.set('userInScope', this);                                                                                 // 47
    },                                                                                                              // 48
                                                                                                                    // 49
    'click [data-action="info"]': function(event, template) {                                                       // 50
		Session.set('userInScope', this);                                                                                 // 51
    },                                                                                                              // 52
                                                                                                                    // 53
    'click [data-action="update"]': function(event, template) {                                                     // 54
		Session.set('userInScope', this);                                                                                 // 55
	  },                                                                                                               // 56
                                                                                                                    // 57
    'click [data-action="addUser"]': function(event, template) {                                                    // 58
		Session.set('userInScope', this);                                                                                 // 59
		},                                                                                                                // 60
                                                                                                                    // 61
		'click [data-action="impersonate"]': function(event, template) {                                                  // 62
			event.preventDefault()                                                                                           // 63
			Session.set('impersonate', this._id);                                                                            // 64
			Meteor.call('impersonate', this._id, Meteor.userId(), function(err, result) {                                    // 65
				if (err)                                                                                                        // 66
					console.log(err);                                                                                              // 67
				Meteor.connection.setUserId(Session.get('impersonate'));                                                        // 68
				Router.go('/');                                                                                                 // 69
			});                                                                                                              // 70
		}                                                                                                                 // 71
});                                                                                                                 // 72
                                                                                                                    // 73
Template.accountsAdmin.rendered = function() {                                                                      // 74
	var searchElement = document.getElementsByClassName('search-input-filter');                                        // 75
	if(!searchElement)                                                                                                 // 76
		return;                                                                                                           // 77
	var filterValue = Session.get("userFilter");                                                                       // 78
                                                                                                                    // 79
	var pos = 0;                                                                                                       // 80
	if (filterValue)                                                                                                   // 81
		pos = filterValue.length;                                                                                         // 82
                                                                                                                    // 83
	searchElement[0].focus();                                                                                          // 84
	searchElement[0].setSelectionRange(pos, pos);                                                                      // 85
};                                                                                                                  // 86
                                                                                                                    // 87
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       // 254
}).call(this);                                                                                                         // 255
                                                                                                                       // 256
                                                                                                                       // 257
                                                                                                                       // 258
                                                                                                                       // 259
                                                                                                                       // 260
                                                                                                                       // 261
(function () {                                                                                                         // 262
                                                                                                                       // 263
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/cfly15:manage-users/client/template.delete_account_modal.js                                             //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
                                                                                                                    // 1
Template.__checkName("deleteAccountModal");                                                                         // 2
Template["deleteAccountModal"] = new Template("Template.deleteAccountModal", (function() {                          // 3
  var view = this;                                                                                                  // 4
  return HTML.DIV({                                                                                                 // 5
    id: "deleteaccount",                                                                                            // 6
    "class": "modal fade",                                                                                          // 7
    tabindex: "-1",                                                                                                 // 8
    "data-width": "760",                                                                                            // 9
    style: "display:none;"                                                                                          // 10
  }, "\n		", HTML.DIV({                                                                                             // 11
    "class": "modal-dialog"                                                                                         // 12
  }, "\n			", HTML.DIV({                                                                                            // 13
    "class": "modal-content"                                                                                        // 14
  }, "\n				", Spacebars.include(view.lookupTemplate("deleteAccountModalInner")), "\n			"), "\n		"), "\n	");        // 15
}));                                                                                                                // 16
                                                                                                                    // 17
Template.__checkName("deleteAccountModalInner");                                                                    // 18
Template["deleteAccountModalInner"] = new Template("Template.deleteAccountModalInner", (function() {                // 19
  var view = this;                                                                                                  // 20
  return Spacebars.With(function() {                                                                                // 21
    return Spacebars.call(view.lookup("userInScope"));                                                              // 22
  }, function() {                                                                                                   // 23
    return [ "\n	 	", HTML.DIV({                                                                                    // 24
      "class": "modal-body"                                                                                         // 25
    }, "\n	 		", HTML.H4("Are you sure you want to delete ", Blaze.View(function() {                                // 26
      return Spacebars.mustache(view.lookup("email"));                                                              // 27
    }), "?"), "\n	 	"), "\n	 	", HTML.DIV({                                                                         // 28
      "class": "modal-footer"                                                                                       // 29
    }, "\n			", HTML.BUTTON({                                                                                       // 30
      type: "button",                                                                                               // 31
      "data-dismiss": "modal",                                                                                      // 32
      "class": "btn btn-default"                                                                                    // 33
    }, "Cancel"), "\n			", HTML.BUTTON({                                                                            // 34
      type: "button",                                                                                               // 35
      "class": "btn btn-danger"                                                                                     // 36
    }, "Delete"), "\n		"), "\n	" ];                                                                                 // 37
  });                                                                                                               // 38
}));                                                                                                                // 39
                                                                                                                    // 40
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       // 311
}).call(this);                                                                                                         // 312
                                                                                                                       // 313
                                                                                                                       // 314
                                                                                                                       // 315
                                                                                                                       // 316
                                                                                                                       // 317
                                                                                                                       // 318
(function () {                                                                                                         // 319
                                                                                                                       // 320
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/cfly15:manage-users/client/delete_account_modal.js                                                      //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
Template.deleteAccountModalInner.helpers({                                                                          // 1
	email: function () {                                                                                               // 2
		if (this.emails && this.emails.length)                                                                            // 3
			return this.emails[0].address;                                                                                   // 4
                                                                                                                    // 5
		if (this.services) {                                                                                              // 6
			//Iterate through services                                                                                       // 7
			for (var serviceName in this.services) {                                                                         // 8
				var serviceObject = this.services[serviceName];                                                                 // 9
				//If an 'id' isset then assume valid service                                                                    // 10
				if (serviceObject.id) {                                                                                         // 11
					if (serviceObject.email) {                                                                                     // 12
						return serviceObject.email;                                                                                   // 13
					}                                                                                                              // 14
				}                                                                                                               // 15
			}                                                                                                                // 16
		}                                                                                                                 // 17
		return "";                                                                                                        // 18
	},                                                                                                                 // 19
	userInScope: function() {                                                                                          // 20
		return Session.get('userInScope');                                                                                // 21
	}                                                                                                                  // 22
});                                                                                                                 // 23
                                                                                                                    // 24
Template.deleteAccountModalInner.events({                                                                           // 25
	'click .btn-danger': function(event, template) {                                                                   // 26
		Meteor.call('deleteUser', this._id, function(error) {                                                             // 27
			if (error) {                                                                                                     // 28
				// optionally use a meteor errors package                                                                       // 29
				if (typeof Errors === "undefined")                                                                              // 30
					Log.error('Error: ' + error.reason);                                                                           // 31
				else {                                                                                                          // 32
					Errors.throw(error.reason);                                                                                    // 33
				}                                                                                                               // 34
			}                                                                                                                // 35
			$("#deleteaccount").modal("hide");                                                                               // 36
		});                                                                                                               // 37
	}                                                                                                                  // 38
});                                                                                                                 // 39
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       // 367
}).call(this);                                                                                                         // 368
                                                                                                                       // 369
                                                                                                                       // 370
                                                                                                                       // 371
                                                                                                                       // 372
                                                                                                                       // 373
                                                                                                                       // 374
(function () {                                                                                                         // 375
                                                                                                                       // 376
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/cfly15:manage-users/client/template.info_account_modal.js                                               //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
                                                                                                                    // 1
Template.__checkName("infoAccountModal");                                                                           // 2
Template["infoAccountModal"] = new Template("Template.infoAccountModal", (function() {                              // 3
  var view = this;                                                                                                  // 4
  return HTML.DIV({                                                                                                 // 5
    id: "infoaccount",                                                                                              // 6
    "class": "modal fade",                                                                                          // 7
    tabindex: "-1",                                                                                                 // 8
    "data-width": "760",                                                                                            // 9
    style: "display:none;"                                                                                          // 10
  }, "\n		", HTML.DIV({                                                                                             // 11
    "class": "modal-dialog"                                                                                         // 12
  }, "\n			", HTML.DIV({                                                                                            // 13
    "class": "modal-content"                                                                                        // 14
  }, "\n				", Spacebars.include(view.lookupTemplate("infoAccountModalInner")), "\n			"), "\n		"), "\n	");          // 15
}));                                                                                                                // 16
                                                                                                                    // 17
Template.__checkName("infoAccountModalInner");                                                                      // 18
Template["infoAccountModalInner"] = new Template("Template.infoAccountModalInner", (function() {                    // 19
  var view = this;                                                                                                  // 20
  return [ HTML.Raw('<div class="modal-header">\n		<h4>Account Info</h4>\n	</div>\n	'), Spacebars.With(function() { // 21
    return Spacebars.call(view.lookup("userInScope"));                                                              // 22
  }, function() {                                                                                                   // 23
    return [ "\n	 	", HTML.DIV({                                                                                    // 24
      "class": "modal-body"                                                                                         // 25
    }, "\n			", HTML.UL({                                                                                           // 26
      "class": "list-group"                                                                                         // 27
    }, "\n				", HTML.LI({                                                                                          // 28
      "class": "list-group-item"                                                                                    // 29
    }, HTML.STRONG("Name"), "\n					", HTML.SPAN({                                                                  // 30
      "class": "pull-right"                                                                                         // 31
    }, "\n						", Blaze.If(function() {                                                                            // 32
      return Spacebars.call(Spacebars.dot(view.lookup("profile"), "name"));                                         // 33
    }, function() {                                                                                                 // 34
      return [ "\n							", Blaze.View(function() {                                                                 // 35
        return Spacebars.mustache(Spacebars.dot(view.lookup("profile"), "name"));                                   // 36
      }), "\n						" ];                                                                                             // 37
    }, function() {                                                                                                 // 38
      return [ "\n							", Blaze.View(function() {                                                                 // 39
        return Spacebars.mustache(view.lookup("email"));                                                            // 40
      }), "\n						" ];                                                                                             // 41
    }), "\n					"), "\n				"), "\n				", HTML.LI({                                                                  // 42
      "class": "list-group-item"                                                                                    // 43
    }, HTML.STRONG("Email"), HTML.SPAN({                                                                            // 44
      "class": "pull-right"                                                                                         // 45
    }, Blaze.View(function() {                                                                                      // 46
      return Spacebars.mustache(view.lookup("email"));                                                              // 47
    }))), "\n				", HTML.LI({                                                                                       // 48
      "class": "list-group-item"                                                                                    // 49
    }, HTML.STRONG("ID"), HTML.SPAN({                                                                               // 50
      "class": "pull-right"                                                                                         // 51
    }, Blaze.View(function() {                                                                                      // 52
      return Spacebars.mustache(view.lookup("_id"));                                                                // 53
    }))), "\n				", Blaze.Each(function() {                                                                         // 54
      return Spacebars.call(view.lookup("rolePairs"));                                                              // 55
    }, function() {                                                                                                 // 56
      return [ "\n					", HTML.LI({                                                                                 // 57
        "class": "list-group-item"                                                                                  // 58
      }, HTML.STRONG(Blaze.View(function() {                                                                        // 59
        return Spacebars.mustache(view.lookup("key"));                                                              // 60
      })), HTML.SPAN({                                                                                              // 61
        "class": "pull-right"                                                                                       // 62
      }, Blaze.View(function() {                                                                                    // 63
        return Spacebars.mustache(view.lookup("value"));                                                            // 64
      }))), "\n				" ];                                                                                             // 65
    }), "\n			"), "\n	 	"), "\n	 	", HTML.DIV({                                                                     // 66
      "class": "modal-footer"                                                                                       // 67
    }, "\n			", HTML.BUTTON({                                                                                       // 68
      type: "button",                                                                                               // 69
      "data-dismiss": "modal",                                                                                      // 70
      "class": "btn btn-primary"                                                                                    // 71
    }, "OK"), "\n		"), "\n	" ];                                                                                     // 72
  }) ];                                                                                                             // 73
}));                                                                                                                // 74
                                                                                                                    // 75
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       // 459
}).call(this);                                                                                                         // 460
                                                                                                                       // 461
                                                                                                                       // 462
                                                                                                                       // 463
                                                                                                                       // 464
                                                                                                                       // 465
                                                                                                                       // 466
(function () {                                                                                                         // 467
                                                                                                                       // 468
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/cfly15:manage-users/client/info_account_modal.js                                                        //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
Template.infoAccountModalInner.helpers({                                                                            // 1
	email: function () {                                                                                               // 2
		if (this.emails && this.emails.length)                                                                            // 3
			return this.emails[0].address;                                                                                   // 4
                                                                                                                    // 5
		if (this.services) {                                                                                              // 6
			//Iterate through services                                                                                       // 7
			for (var serviceName in this.services) {                                                                         // 8
				var serviceObject = this.services[serviceName];                                                                 // 9
				//If an 'id' isset then assume valid service                                                                    // 10
				if (serviceObject.id) {                                                                                         // 11
					if (serviceObject.email) {                                                                                     // 12
						return serviceObject.email;                                                                                   // 13
					}                                                                                                              // 14
				}                                                                                                               // 15
			}                                                                                                                // 16
		}                                                                                                                 // 17
		return "";                                                                                                        // 18
	},                                                                                                                 // 19
                                                                                                                    // 20
	userInScope: function() {                                                                                          // 21
		return Session.get('userInScope');                                                                                // 22
	},                                                                                                                 // 23
                                                                                                                    // 24
	rolePairs: function() {                                                                                            // 25
		var pairs = [];                                                                                                   // 26
		if (!this.roles)                                                                                                  // 27
			pairs.push({key: 'Roles', value: 'None'});                                                                       // 28
                                                                                                                    // 29
		for (var role in this.roles) {                                                                                    // 30
			var r = this.roles[role];                                                                                        // 31
			if (role === '0') {                                                                                              // 32
				pairs.push({key: 'Roles', value: r});                                                                           // 33
			} else {                                                                                                         // 34
				pairs.push({key: '-', value: r});                                                                               // 35
			}                                                                                                                // 36
		}                                                                                                                 // 37
		return pairs;                                                                                                     // 38
	}                                                                                                                  // 39
});                                                                                                                 // 40
                                                                                                                    // 41
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       // 517
}).call(this);                                                                                                         // 518
                                                                                                                       // 519
                                                                                                                       // 520
                                                                                                                       // 521
                                                                                                                       // 522
                                                                                                                       // 523
                                                                                                                       // 524
(function () {                                                                                                         // 525
                                                                                                                       // 526
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/cfly15:manage-users/client/template.update_account_modal.js                                             //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
                                                                                                                    // 1
Template.__checkName("updateAccountModal");                                                                         // 2
Template["updateAccountModal"] = new Template("Template.updateAccountModal", (function() {                          // 3
  var view = this;                                                                                                  // 4
  return HTML.DIV({                                                                                                 // 5
    id: "updateaccount",                                                                                            // 6
    "class": "modal fade",                                                                                          // 7
    tabindex: "-1",                                                                                                 // 8
    "data-width": "760",                                                                                            // 9
    style: "display:none;"                                                                                          // 10
  }, "\n		", HTML.DIV({                                                                                             // 11
    "class": "modal-dialog"                                                                                         // 12
  }, "\n			", HTML.DIV({                                                                                            // 13
    "class": "modal-content"                                                                                        // 14
  }, "\n				", Spacebars.include(view.lookupTemplate("updateAccountModalInner")), "\n			"), "\n		"), "\n	");        // 15
}));                                                                                                                // 16
                                                                                                                    // 17
Template.__checkName("updateAccountModalInner");                                                                    // 18
Template["updateAccountModalInner"] = new Template("Template.updateAccountModalInner", (function() {                // 19
  var view = this;                                                                                                  // 20
  return Spacebars.With(function() {                                                                                // 21
    return Spacebars.call(view.lookup("userInScope"));                                                              // 22
  }, function() {                                                                                                   // 23
    return [ "\n		", HTML.DIV({                                                                                     // 24
      "class": "modal-header"                                                                                       // 25
    }, "\n			", HTML.H4("Update ", Blaze.View(function() {                                                          // 26
      return Spacebars.mustache(view.lookup("email"));                                                              // 27
    })), "\n		"), "\n		", HTML.DIV({                                                                                // 28
      "class": "modal-body"                                                                                         // 29
    }, "\n			", HTML.DIV({                                                                                          // 30
      "class": "form-group"                                                                                         // 31
    }, "\n				", HTML.DIV({                                                                                         // 32
      "class": "input-group"                                                                                        // 33
    }, "\n					", HTML.SPAN({                                                                                       // 34
      "class": "input-group-addon"                                                                                  // 35
    }, "Name"), "\n					", HTML.INPUT({                                                                             // 36
      "data-user-id": function() {                                                                                  // 37
        return Spacebars.mustache(view.lookup("_id"));                                                              // 38
      },                                                                                                            // 39
      "class": "form-control admin-user-info",                                                                      // 40
      name: "profile.name",                                                                                         // 41
      value: function() {                                                                                           // 42
        return Spacebars.mustache(Spacebars.dot(view.lookup("profile"), "name"));                                   // 43
      },                                                                                                            // 44
      placeholder: function() {                                                                                     // 45
        return Spacebars.mustache(view.lookup("email"));                                                            // 46
      }                                                                                                             // 47
    }), "\n				"), "\n			"), "\n			", Blaze.If(function() {                                                         // 48
      return Spacebars.call(view.lookup("roles"));                                                                  // 49
    }, function() {                                                                                                 // 50
      return [ "\n				", HTML.UL({                                                                                  // 51
        "class": "list-group"                                                                                       // 52
      }, "\n					", Blaze.Each(function() {                                                                         // 53
        return Spacebars.call(view.lookup("roles"));                                                                // 54
      }, function() {                                                                                               // 55
        return [ "\n						", HTML.LI({                                                                              // 56
          "class": "list-group-item"                                                                                // 57
        }, "\n							", HTML.BUTTON({                                                                               // 58
          "data-user-id": function() {                                                                              // 59
            return Spacebars.mustache(Spacebars.dot(view.lookup(".."), "_id"));                                     // 60
          },                                                                                                        // 61
          "class": "btn btn-danger btn-xs remove-role",                                                             // 62
          type: "button"                                                                                            // 63
        }, "Remove"), "\n							", HTML.SPAN({                                                                      // 64
          "class": "pull-right"                                                                                     // 65
        }, Blaze.View(function() {                                                                                  // 66
          return Spacebars.mustache(view.lookup("."));                                                              // 67
        })), "\n						"), "\n					" ];                                                                              // 68
      }), "\n				"), "\n			" ];                                                                                     // 69
    }, function() {                                                                                                 // 70
      return "\n				This account has no roles.\n			";                                                               // 71
    }), "\n			", Blaze.If(function() {                                                                              // 72
      return Spacebars.call(view.lookup("unsetRoles"));                                                             // 73
    }, function() {                                                                                                 // 74
      return [ "\n			", HTML.DIV({                                                                                  // 75
        "class": "btn-group clearfix full-width"                                                                    // 76
      }, "\n				", HTML.BUTTON({                                                                                    // 77
        type: "button",                                                                                             // 78
        "class": "btn btn-success dropdown-toggle pull-right",                                                      // 79
        "data-toggle": "dropdown"                                                                                   // 80
      }, "\n					", HTML.SPAN({                                                                                     // 81
        "class": "glyphicon glyphicon-plus"                                                                         // 82
      }), " Add Role \n				"), "\n				", HTML.UL({                                                                  // 83
        "class": "dropdown-menu pull-right",                                                                        // 84
        role: "menu"                                                                                                // 85
      }, "\n					", Blaze.Each(function() {                                                                         // 86
        return Spacebars.call(view.lookup("unsetRoles"));                                                           // 87
      }, function() {                                                                                               // 88
        return [ "\n						", HTML.LI(HTML.A({                                                                       // 89
          href: "#",                                                                                                // 90
          "class": "add-role",                                                                                      // 91
          "data-user-id": function() {                                                                              // 92
            return Spacebars.mustache(Spacebars.dot(view.lookup(".."), "_id"));                                     // 93
          }                                                                                                         // 94
        }, Blaze.View(function() {                                                                                  // 95
          return Spacebars.mustache(view.lookup("."));                                                              // 96
        }))), "\n					" ];                                                                                          // 97
      }), "\n				"), "\n			"), "\n			" ];                                                                           // 98
    }, function() {                                                                                                 // 99
      return [ "\n			", HTML.EM("All roles already set."), "\n			" ];                                               // 100
    }), "\n		"), "\n		", HTML.DIV({                                                                                 // 101
      "class": "modal-footer"                                                                                       // 102
    }, "\n			", HTML.BUTTON({                                                                                       // 103
      type: "button",                                                                                               // 104
      "data-dismiss": "modal",                                                                                      // 105
      "class": "btn btn-primary"                                                                                    // 106
    }, "Done"), "\n		"), "\n	" ];                                                                                   // 107
  });                                                                                                               // 108
}));                                                                                                                // 109
                                                                                                                    // 110
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       // 644
}).call(this);                                                                                                         // 645
                                                                                                                       // 646
                                                                                                                       // 647
                                                                                                                       // 648
                                                                                                                       // 649
                                                                                                                       // 650
                                                                                                                       // 651
(function () {                                                                                                         // 652
                                                                                                                       // 653
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/cfly15:manage-users/client/update_account_modal.js                                                      //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
Template.updateAccountModalInner.helpers({                                                                          // 1
	email: function () {                                                                                               // 2
		if (this.emails && this.emails.length)                                                                            // 3
			return this.emails[0].address;                                                                                   // 4
                                                                                                                    // 5
		if (this.services) {                                                                                              // 6
			//Iterate through services                                                                                       // 7
			for (var serviceName in this.services) {                                                                         // 8
				var serviceObject = this.services[serviceName];                                                                 // 9
				//If an 'id' isset then assume valid service                                                                    // 10
				if (serviceObject.id) {                                                                                         // 11
					if (serviceObject.email) {                                                                                     // 12
						return serviceObject.email;                                                                                   // 13
					}                                                                                                              // 14
				}                                                                                                               // 15
			}                                                                                                                // 16
		}                                                                                                                 // 17
		return "";                                                                                                        // 18
	},                                                                                                                 // 19
                                                                                                                    // 20
	userInScope: function() {                                                                                          // 21
		return Session.get('userInScope');                                                                                // 22
	},                                                                                                                 // 23
                                                                                                                    // 24
	unsetRoles: function() {                                                                                           // 25
		var allRoles = _.pluck(Roles.getAllRoles().fetch(), "name");                                                      // 26
		if (!this.roles)                                                                                                  // 27
			return allRoles;                                                                                                 // 28
		return _.difference(allRoles, this.roles);                                                                        // 29
	}                                                                                                                  // 30
});                                                                                                                 // 31
                                                                                                                    // 32
Template.updateAccountModalInner.events({                                                                           // 33
	'click .add-role': function(event, template) {                                                                     // 34
		var role = this.toString();                                                                                       // 35
		var userId = event.currentTarget.getAttribute('data-user-id');                                                    // 36
		Meteor.call('addUserRole', userId, role, function(error) {                                                        // 37
			if (error) {                                                                                                     // 38
				// optionally use a meteor errors package                                                                       // 39
				if (typeof Errors === "undefined")                                                                              // 40
					Log.error('Error: ' + error.reason);                                                                           // 41
				else {                                                                                                          // 42
					Errors.throw(error.reason);                                                                                    // 43
				}                                                                                                               // 44
			}                                                                                                                // 45
                                                                                                                    // 46
			//update the data in the session variable to update modal templates                                              // 47
			Session.set('userInScope', Meteor.users.findOne(userId));                                                        // 48
		});                                                                                                               // 49
	},                                                                                                                 // 50
                                                                                                                    // 51
	'click .remove-role' : function(event, template) {                                                                 // 52
		var role = this.toString();                                                                                       // 53
		var userId = event.currentTarget.getAttribute('data-user-id');                                                    // 54
                                                                                                                    // 55
		Meteor.call('removeUserRole', userId, role, function(error) {                                                     // 56
			if (error) {                                                                                                     // 57
				// optionally use a meteor errors package                                                                       // 58
				if (typeof Errors === "undefined")                                                                              // 59
					Log.error('Error: ' + error.reason);                                                                           // 60
				else {                                                                                                          // 61
					Errors.throw(error.reason);                                                                                    // 62
				}                                                                                                               // 63
			}                                                                                                                // 64
                                                                                                                    // 65
			//update the data in the session variable to update modal templates                                              // 66
			Session.set('userInScope', Meteor.users.findOne(userId));                                                        // 67
		});                                                                                                               // 68
	},                                                                                                                 // 69
                                                                                                                    // 70
	'change .admin-user-info' : function(event, template) {                                                            // 71
                                                                                                                    // 72
		var ele = event.currentTarget;                                                                                    // 73
		var userId = ele.getAttribute('data-user-id');                                                                    // 74
                                                                                                                    // 75
		Meteor.call('updateUserInfo', userId, ele.name, ele.value, function(error) {                                      // 76
			if (error)                                                                                                       // 77
			{                                                                                                                // 78
				if (typeof Errors === "undefined") Log.error('Error: ' + error.reason);                                         // 79
				else Errors.throw(error.reason);                                                                                // 80
				return;                                                                                                         // 81
			}                                                                                                                // 82
			Session.set('userInScope', Meteor.users.findOne(userId));                                                        // 83
		});                                                                                                               // 84
	}                                                                                                                  // 85
});                                                                                                                 // 86
                                                                                                                    // 87
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       // 748
}).call(this);                                                                                                         // 749
                                                                                                                       // 750
                                                                                                                       // 751
                                                                                                                       // 752
                                                                                                                       // 753
                                                                                                                       // 754
                                                                                                                       // 755
(function () {                                                                                                         // 756
                                                                                                                       // 757
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/cfly15:manage-users/client/template.update_roles_modal.js                                               //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
                                                                                                                    // 1
Template.__checkName("updateRolesModal");                                                                           // 2
Template["updateRolesModal"] = new Template("Template.updateRolesModal", (function() {                              // 3
  var view = this;                                                                                                  // 4
  return HTML.DIV({                                                                                                 // 5
    id: "updateroles",                                                                                              // 6
    "class": "modal fade",                                                                                          // 7
    tabindex: "-1",                                                                                                 // 8
    "data-width": "760",                                                                                            // 9
    style: "display:none;"                                                                                          // 10
  }, "\n		", HTML.DIV({                                                                                             // 11
    "class": "modal-dialog"                                                                                         // 12
  }, "\n			", HTML.DIV({                                                                                            // 13
    "class": "modal-content"                                                                                        // 14
  }, "\n				", Spacebars.include(view.lookupTemplate("updateRolesModalInner")), "\n			"), "\n		"), "\n	");          // 15
}));                                                                                                                // 16
                                                                                                                    // 17
Template.__checkName("updateRolesModalInner");                                                                      // 18
Template["updateRolesModalInner"] = new Template("Template.updateRolesModalInner", (function() {                    // 19
  var view = this;                                                                                                  // 20
  return [ HTML.Raw('<div class="modal-header">\n		<h4>Update Roles</h4>\n	</div>\n 	'), HTML.DIV({                 // 21
    "class": "modal-body"                                                                                           // 22
  }, "\n 		", HTML.UL({                                                                                             // 23
    "class": "list-group"                                                                                           // 24
  }, "\n			", Blaze.Each(function() {                                                                               // 25
    return Spacebars.call(view.lookup("roles"));                                                                    // 26
  }, function() {                                                                                                   // 27
    return [ "\n				", Blaze.If(function() {                                                                        // 28
      return Spacebars.call(view.lookup("adminRole"));                                                              // 29
    }, function() {                                                                                                 // 30
      return [ "\n					", HTML.LI({                                                                                 // 31
        "class": "list-group-item"                                                                                  // 32
      }, "\n						", HTML.EM("Admin Role"), "\n						", HTML.SPAN({                                                 // 33
        "class": "pull-right"                                                                                       // 34
      }, Blaze.View(function() {                                                                                    // 35
        return Spacebars.mustache(Spacebars.dot(view.lookup("."), "name"));                                         // 36
      })), "\n					"), "\n				" ];                                                                                  // 37
    }, function() {                                                                                                 // 38
      return [ "\n					", HTML.LI({                                                                                 // 39
        "class": "list-group-item"                                                                                  // 40
      }, "\n						", HTML.BUTTON({                                                                                  // 41
        "class": "btn btn-danger btn-xs remove-role",                                                               // 42
        type: "button"                                                                                              // 43
      }, "Delete"), "\n						", HTML.SPAN({                                                                         // 44
        "class": "pull-right"                                                                                       // 45
      }, Blaze.View(function() {                                                                                    // 46
        return Spacebars.mustache(Spacebars.dot(view.lookup("."), "name"));                                         // 47
      })), "\n					"), "\n				" ];                                                                                  // 48
    }), "\n			" ];                                                                                                  // 49
  }), "\n		"), "\n		", HTML.Raw('<div class="input-group">\n			<input type="text" class="form-control add-role-input" value="">\n			<span class="input-group-btn">\n				<button class="btn btn-success add-role disabled" type="button"><span class="glyphicon glyphicon-plus"></span> Create Role</button>\n			</span>\n		</div>'), "\n 	"), HTML.Raw('\n 	<div class="modal-footer">\n		<button type="button" data-dismiss="modal" class="btn btn-primary">Done</button>\n	</div>') ];
}));                                                                                                                // 51
                                                                                                                    // 52
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       // 817
}).call(this);                                                                                                         // 818
                                                                                                                       // 819
                                                                                                                       // 820
                                                                                                                       // 821
                                                                                                                       // 822
                                                                                                                       // 823
                                                                                                                       // 824
(function () {                                                                                                         // 825
                                                                                                                       // 826
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/cfly15:manage-users/client/update_roles_modal.js                                                        //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
Template.updateRolesModalInner.helpers({                                                                            // 1
	roles: function() {                                                                                                // 2
		return Roles.getAllRoles();                                                                                       // 3
	},                                                                                                                 // 4
	adminRole: function() {                                                                                            // 5
		return this.name === 'admin';                                                                                     // 6
	}                                                                                                                  // 7
});                                                                                                                 // 8
                                                                                                                    // 9
Template.updateRolesModalInner.events({                                                                             // 10
	'click .add-role': function(event, template) {                                                                     // 11
		var role = template.find('.add-role-input').value;                                                                // 12
		Meteor.call('addRole', role, function(error) {                                                                    // 13
			if (error) {                                                                                                     // 14
				// optionally use a meteor errors package                                                                       // 15
				if (typeof Errors === "undefined")                                                                              // 16
					Log.error('Error: ' + error.reason);                                                                           // 17
				else {                                                                                                          // 18
					Errors.throw(error.reason);                                                                                    // 19
				}                                                                                                               // 20
			}                                                                                                                // 21
			template.find('.add-role-input').value = "";                                                                     // 22
		});                                                                                                               // 23
	},                                                                                                                 // 24
                                                                                                                    // 25
	'click .remove-role' : function(event, template) {                                                                 // 26
		var role = this.name;                                                                                             // 27
                                                                                                                    // 28
		Meteor.call('removeRole', role, function(error) {                                                                 // 29
			if (error) {                                                                                                     // 30
				// optionally use a meteor errors package                                                                       // 31
				if (typeof Errors === "undefined")                                                                              // 32
					Log.error('Error: ' + error.reason);                                                                           // 33
				else {                                                                                                          // 34
					Errors.throw(error.reason);                                                                                    // 35
				}                                                                                                               // 36
			}                                                                                                                // 37
		});                                                                                                               // 38
	},                                                                                                                 // 39
                                                                                                                    // 40
	'keyup .add-role-input': function(event, template) {                                                               // 41
		var buttonElement = template.find('.add-role');                                                                   // 42
		var role = template.find('.add-role-input').value;                                                                // 43
		if (!role) {                                                                                                      // 44
			buttonElement.classList.add('disabled');                                                                         // 45
		} else {                                                                                                          // 46
			buttonElement.classList.remove('disabled');                                                                      // 47
		}                                                                                                                 // 48
                                                                                                                    // 49
		if (event.keyCode === 13 && !!role) {                                                                             // 50
			Meteor.call('addRole', role, function(error) {                                                                   // 51
				if (error) {                                                                                                    // 52
					// optionally use a meteor errors package                                                                      // 53
					if (typeof Errors === "undefined")                                                                             // 54
						Log.error('Error: ' + error.reason);                                                                          // 55
					else {                                                                                                         // 56
						Errors.throw(error.reason);                                                                                   // 57
					}                                                                                                              // 58
				}                                                                                                               // 59
				template.find('.add-role-input').value = "";                                                                    // 60
				buttonElement.classList.add('disabled');                                                                        // 61
			});                                                                                                              // 62
		}                                                                                                                 // 63
	}                                                                                                                  // 64
});                                                                                                                 // 65
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       // 899
}).call(this);                                                                                                         // 900
                                                                                                                       // 901
                                                                                                                       // 902
                                                                                                                       // 903
                                                                                                                       // 904
                                                                                                                       // 905
                                                                                                                       // 906
(function () {                                                                                                         // 907
                                                                                                                       // 908
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/cfly15:manage-users/client/template.add_user_modal.js                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
                                                                                                                    // 1
Template.__checkName("addUserModal");                                                                               // 2
Template["addUserModal"] = new Template("Template.addUserModal", (function() {                                      // 3
  var view = this;                                                                                                  // 4
  return HTML.Raw('<div id="addUser" class="modal fade" tabindex="-1" data-width="760" style="display:none;">\n    <div class="modal-dialog">\n      <div class="modal-content">\n        <div class="modal-header">\n          <h4>Add New User</h4>\n        </div>\n           <div class="modal-body">\n             <div class="form-group">\n               <div class="input-group">\n                 <span class="input-group-addon">Name</span>\n                 <input class="form-control" name="name">\n               </div>\n            </div>\n\n            <div class="form-group">\n               <div class="input-group">\n                 <span class="input-group-addon">Email</span>\n                 <input class="form-control" type="email" name="email">\n               </div>\n            </div>\n\n            <div class="form-group">\n               <div class="input-group">\n                 <span class="input-group-addon">Password</span>\n                 <input class="form-control" type="password" name="password">\n               </div>\n             </div>\n            </div>\n           <div class="modal-footer">\n            <button type="button" data-action="submitAddUser" class="btn btn-primary">Add User</button>\n          </div>\n      </div>\n    </div>\n  </div>');
}));                                                                                                                // 6
                                                                                                                    // 7
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       // 923
}).call(this);                                                                                                         // 924
                                                                                                                       // 925
                                                                                                                       // 926
                                                                                                                       // 927
                                                                                                                       // 928
                                                                                                                       // 929
                                                                                                                       // 930
(function () {                                                                                                         // 931
                                                                                                                       // 932
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/cfly15:manage-users/client/add_user_modal.js                                                            //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
Template.addUserModal.events({                                                                                      // 1
  "click [data-action='submitAddUser']": function(e) {                                                              // 2
    var email, name, password;                                                                                      // 3
    e.preventDefault();                                                                                             // 4
    name = $("[name='name']").val();                                                                                // 5
    email = $("[name='email']").val();                                                                              // 6
    password = $("[name='password']").val();                                                                        // 7
    Meteor.call('addUser', name, email, password, function(err, result) {                                           // 8
      if (err) {                                                                                                    // 9
        return console.log(err);                                                                                    // 10
      }                                                                                                             // 11
    });                                                                                                             // 12
    return $('#addUser').modal('hide');                                                                             // 13
  }                                                                                                                 // 14
});                                                                                                                 // 15
                                                                                                                    // 16
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       // 956
}).call(this);                                                                                                         // 957
                                                                                                                       // 958
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['cfly15:manage-users'] = {}, {
  ManageUsers: ManageUsers
});

})();
