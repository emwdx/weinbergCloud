/* Imports for global scope */

Router = Package['iron:router'].Router;
RouteController = Package['iron:router'].RouteController;
Logic = Package['logic-solver'].Logic;
Roles = Package['alanning:roles'].Roles;
ManageUsers = Package['cfly15:manage-users'].ManageUsers;
ReactiveVar = Package['reactive-var'].ReactiveVar;
_ = Package.underscore._;
$ = Package.jquery.$;
jQuery = Package.jquery.jQuery;
Raphael = Package['clubfest:raphael'].Raphael;
Accounts = Package['accounts-base'].Accounts;
Iron = Package['iron:core'].Iron;
AccountsTemplates = Package['useraccounts:core'].AccountsTemplates;
Meteor = Package.meteor.Meteor;
global = Package.meteor.global;
meteorEnv = Package.meteor.meteorEnv;
WebApp = Package.webapp.WebApp;
Log = Package.logging.Log;
Tracker = Package.deps.Tracker;
Deps = Package.deps.Deps;
Session = Package.session.Session;
DDP = Package['ddp-client'].DDP;
Mongo = Package.mongo.Mongo;
Blaze = Package.ui.Blaze;
UI = Package.ui.UI;
Handlebars = Package.ui.Handlebars;
Spacebars = Package.spacebars.Spacebars;
Template = Package.templating.Template;
check = Package.check.check;
Match = Package.check.Match;
Random = Package.random.Random;
EJSON = Package.ejson.EJSON;
LaunchScreen = Package['launch-screen'].LaunchScreen;
T9n = Package['softwarerero:accounts-t9n'].T9n;
HTML = Package.htmljs.HTML;

