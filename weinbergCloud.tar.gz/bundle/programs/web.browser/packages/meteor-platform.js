(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var Reload = Package.reload.Reload;
var Autoupdate = Package.autoupdate.Autoupdate;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['meteor-platform'] = {};

})();
