//////////////////////////////////////////////////////////////////////////
//                                                                      //
// This is a generated file. You can view the original                  //
// source in your browser if your browser supports source maps.         //
// Source maps are supported by all recent versions of Chrome, Safari,  //
// and Firefox, and by Internet Explorer 11.                            //
//                                                                      //
//////////////////////////////////////////////////////////////////////////


(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var _ = Package.underscore._;
var meteorInstall = Package['modules-runtime'].meteorInstall;

/* Package-scope variables */
var Buffer, process;

var require = meteorInstall({"node_modules":{"meteor":{"modules":{"client.js":["./install-packages.js","./stubs.js","./buffer.js","./process.js","./css",function(require,exports){

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/modules/client.js                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
require("./install-packages.js");                                         // 1
require("./stubs.js");                                                    // 2
require("./buffer.js");                                                   // 3
require("./process.js");                                                  // 4
                                                                          // 5
exports.addStyles = require("./css").addStyles;                           // 6
                                                                          // 7
////////////////////////////////////////////////////////////////////////////

}],"buffer.js":["buffer",function(require){

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/modules/buffer.js                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
try {                                                                     // 1
  Buffer = global.Buffer || require("buffer").Buffer;                     // 2
} catch (noBuffer) {}                                                     // 3
                                                                          // 4
////////////////////////////////////////////////////////////////////////////

}],"css.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/modules/css.js                                                //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
var doc = document;                                                       // 1
var head = doc.getElementsByTagName("head").item(0);                      // 2
                                                                          // 3
exports.addStyles = function (css) {                                      // 4
  var style = doc.createElement("style");                                 // 5
                                                                          // 6
  style.setAttribute("type", "text/css");                                 // 7
                                                                          // 8
  // https://msdn.microsoft.com/en-us/library/ms535871(v=vs.85).aspx      // 9
  var internetExplorerSheetObject =                                       // 10
    style.sheet || // Edge/IE11.                                          // 11
    style.styleSheet; // Older IEs.                                       // 12
                                                                          // 13
  if (internetExplorerSheetObject) {                                      // 14
    internetExplorerSheetObject.cssText = css;                            // 15
  } else {                                                                // 16
    style.appendChild(doc.createTextNode(css));                           // 17
  }                                                                       // 18
                                                                          // 19
  return head.appendChild(style);                                         // 20
};                                                                        // 21
                                                                          // 22
////////////////////////////////////////////////////////////////////////////

},"install-packages.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/modules/install-packages.js                                   //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
function install(name) {                                                  // 1
  var meteorDir = {};                                                     // 2
                                                                          // 3
  // Given a package name <name>, install a stub module in the            // 4
  // /node_modules/meteor directory called <name>.js, so that             // 5
  // require.resolve("meteor/<name>") will always return                  // 6
  // /node_modules/meteor/<name>.js instead of something like             // 7
  // /node_modules/meteor/<name>/index.js, in the rare but possible event
  // that the package contains a file called index.js (#6590).            // 9
  meteorDir[name + ".js"] = function (r, e, module) {                     // 10
    module.exports = Package[name];                                       // 11
  };                                                                      // 12
                                                                          // 13
  meteorInstall({                                                         // 14
    node_modules: {                                                       // 15
      meteor: meteorDir                                                   // 16
    }                                                                     // 17
  });                                                                     // 18
}                                                                         // 19
                                                                          // 20
// This file will be modified during computeJsOutputFilesMap to include   // 21
// install(<name>) calls for every Meteor package.                        // 22
                                                                          // 23
install("underscore");                                                    // 24
install("meteor");                                                        // 25
install("standard-app-packages");                                         // 26
install("tracker");                                                       // 27
install("babel-compiler");                                                // 28
install("ecmascript");                                                    // 29
install("ddp-rate-limiter");                                              // 30
install("modules-runtime");                                               // 31
install("modules");                                                       // 32
install("promise");                                                       // 33
install("ecmascript-runtime");                                            // 34
install("babel-runtime");                                                 // 35
install("random");                                                        // 36
install("localstorage");                                                  // 37
install("callback-hook");                                                 // 38
install("base64");                                                        // 39
install("ejson");                                                         // 40
install("check");                                                         // 41
install("retry");                                                         // 42
install("id-map");                                                        // 43
install("ddp-common");                                                    // 44
install("reload");                                                        // 45
install("diff-sequence");                                                 // 46
install("mongo-id");                                                      // 47
install("ddp-client");                                                    // 48
install("ddp");                                                           // 49
install("ordered-dict");                                                  // 50
install("geojson-utils");                                                 // 51
install("minimongo");                                                     // 52
install("ddp-server");                                                    // 53
install("allow-deny");                                                    // 54
install("mongo");                                                         // 55
install("jquery");                                                        // 56
install("deps");                                                          // 57
install("htmljs");                                                        // 58
install("observe-sequence");                                              // 59
install("reactive-var");                                                  // 60
install("blaze");                                                         // 61
install("accounts-base");                                                 // 62
install("service-configuration");                                         // 63
install("spacebars");                                                     // 64
install("templating");                                                    // 65
install("reactive-dict");                                                 // 66
install("session");                                                       // 67
install("npm-bcrypt");                                                    // 68
install("sha");                                                           // 69
install("srp");                                                           // 70
install("accounts-password");                                             // 71
install("less");                                                          // 72
install("accounts-ui-unstyled");                                          // 73
install("accounts-ui");                                                   // 74
install("ui");                                                            // 75
install("iron:core");                                                     // 76
install("iron:dynamic-template");                                         // 77
install("iron:layout");                                                   // 78
install("iron:url");                                                      // 79
install("iron:middleware-stack");                                         // 80
install("iron:location");                                                 // 81
install("iron:controller");                                               // 82
install("iron:router");                                                   // 83
install("sacha:spin");                                                    // 84
install("logic-solver");                                                  // 85
install("twbs:bootstrap");                                                // 86
install("alanning:roles");                                                // 87
install("useraccounts:core");                                             // 88
install("coffeescript");                                                  // 89
install("softwarerero:accounts-t9n");                                     // 90
install("useraccounts:bootstrap");                                        // 91
install("autoupdate");                                                    // 92
install("meteor-platform");                                               // 93
install("webapp");                                                        // 94
install("logging");                                                       // 95
install("livedata");                                                      // 96
install("launch-screen");                                                 // 97
install("cfly15:manage-users");                                           // 98
install("sashko:katex");                                                  // 99
install("clubfest:raphael");                                              // 100
install("standard-minifier-css");                                         // 101
install("simple:katex");                                                  // 102
                                                                          // 103
////////////////////////////////////////////////////////////////////////////

},"process.js":["process",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/modules/process.js                                            //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
try {                                                                     // 1
  // The application can run `npm install process` to provide its own     // 2
  // process stub; otherwise this module will provide a partial stub.     // 3
  process = global.process || require("process");                         // 4
} catch (noProcess) {                                                     // 5
  process = {};                                                           // 6
}                                                                         // 7
                                                                          // 8
if (Meteor.isServer) {                                                    // 9
  // Make require("process") work on the server in all versions of Node.  // 10
  meteorInstall({                                                         // 11
    node_modules: {                                                       // 12
      "process.js": function (r, e, module) {                             // 13
        module.exports = process;                                         // 14
      }                                                                   // 15
    }                                                                     // 16
  });                                                                     // 17
} else {                                                                  // 18
  process.platform = "browser";                                           // 19
  process.nextTick = process.nextTick || Meteor._setImmediate;            // 20
}                                                                         // 21
                                                                          // 22
if (typeof process.env !== "object") {                                    // 23
  process.env = {};                                                       // 24
}                                                                         // 25
                                                                          // 26
_.extend(process.env, meteorEnv);                                         // 27
                                                                          // 28
////////////////////////////////////////////////////////////////////////////

}],"stubs.js":["meteor-node-stubs",function(require){

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/modules/stubs.js                                              //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
try {                                                                     // 1
  // When meteor-node-stubs is installed in the application's root        // 2
  // node_modules directory, requiring it here installs aliases for stubs
  // for all Node built-in modules, such as fs, util, and http.           // 4
  require("meteor-node-stubs");                                           // 5
} catch (noStubs) {}                                                      // 6
                                                                          // 7
////////////////////////////////////////////////////////////////////////////

}]}}}},{"extensions":[".js",".json"]});
var exports = require("./node_modules/meteor/modules/client.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package.modules = exports, {
  meteorInstall: meteorInstall,
  Buffer: Buffer,
  process: process
});

})();
